<div align="center">

```
███████╗ █████╗ ██████╗ ██╗  ██╗ █████╗ ██████╗ 
██╔════╝██╔══██╗██╔══██╗██║ ██╔╝██╔══██╗██╔══██╗
███████╗███████║██████╔╝█████╔╝ ███████║██████╔╝
╚════██║██╔══██║██╔══██╗██╔═██╗ ██╔══██║██╔══██╗
███████║██║  ██║██║  ██║██║  ██╗██║  ██║██║  ██║
╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝
```

# SARKAR — License Management System

**Military-grade license orchestration. Built for the elite.**

[![Version](https://img.shields.io/badge/VERSION-2.0.0-1e64dc?style=for-the-badge&logo=github&logoColor=white)](.)
[![Status](https://img.shields.io/badge/STATUS-LIVE-22d3a0?style=for-the-badge)](.)
[![Security](https://img.shields.io/badge/SECURITY-AES--256-e8952a?style=for-the-badge)](.)
[![License](https://img.shields.io/badge/LICENSE-PRIVATE-ff4560?style=for-the-badge)](.)
[![Build](https://img.shields.io/badge/BUILD-PASSING-22d3a0?style=for-the-badge&logo=vite)](.)

<br/>

> **SARKAR VIP PANEL** — Real-time license orchestration with enterprise-grade security protocols, mesh networking, and AI-powered threat intelligence. Zero tolerance for unauthorized access.

<br/>

```
◈ ACTIVE NODES: 29        ◈ INVENTORY: 30         ◈ USERS: 50+
◈ NETWORK LOAD: 1245      ◈ SYSTEM: ONLINE        ◈ REGION: IN-WEST
```

</div>

---

## ⚡ What is SARKAR?

**SARKAR** is a next-generation **License Management & Control Panel** engineered for maximum security, real-time monitoring, and blazing-fast key orchestration. It is not just a dashboard — it is a command center.

Built on a foundation of **encrypted mesh networks**, **AI-driven firewall systems**, and **biometric authentication**, SARKAR gives operators god-mode control over their entire license ecosystem from a single pane of glass.

---

## 🛡️ Security Architecture

SARKAR is built on six layers of hardened security — each one a wall, together they are a fortress.

| Layer | Technology | Status |
|-------|-----------|--------|
| 🔐 **Transport** | AES-256 Encrypted Protocol | `ACTIVE` |
| 📱 **Auth** | OTP Verification + Biometric | `ACTIVE` |
| 🌐 **Network** | DDoS Protection + Rate Limiting | `ACTIVE` |
| 🔥 **Firewall** | AI Firewall + Blast Firewall | `ACTIVE` |
| 🎯 **Access** | IP Whitelisting + Zero Trust | `ACTIVE` |
| 🧠 **Intel** | Real-time Threat Intelligence | `ACTIVE` |

---

## 🚀 Tech Stack

```
┌─────────────────────────────────────────────────────────┐
│                    SARKAR TECH STACK                    │
├─────────────┬───────────────────────────────────────────┤
│  Frontend   │  React 18 + TypeScript + Vite             │
│  Styling    │  Tailwind CSS + Custom Animations          │
│  UI Library │  shadcn/ui — Headless Components           │
│  Build Tool │  Vite — Sub-second HMR                    │
│  Security   │  AES-256 + OTP + IP Whitelisting           │
│  Network    │  Mesh Network + Global CDN                 │
│  Auth       │  Lightning Auth + Biometric                │
└─────────────┴───────────────────────────────────────────┘
```

---

## 📊 Control Panel Features

### 🔑 Key Management
- **Keys List** — Full inventory of all issued license keys
- **Generate** — Spin up new keys with custom parameters
- **Bot Keys** — Automated key distribution system
- **Unused Keys** — Audit and recover dormant licenses
- **Expired Keys** — Lifecycle management and renewal
- **Pricing** — Dynamic pricing engine

### 👥 User Management
- Complete user role and permission control
- Real-time session monitoring
- Ghost Panel access for stealth operations
- Request Analyser for deep traffic inspection

### 🖥️ Server Control
- Live system metrics dashboard
- Traffic Monitoring — Real-time infrastructure load
- Multi-region support (IN-WEST and expanding)
- Edge Nodes management

### 🌐 Network Intelligence
- AI Firewall with adaptive threat response
- Mesh Network topology visualization
- Encrypted DB — Zero-cleartext storage
- Real-time Threat Intel feed
- Shield Protocol — Last-line defense
- Lightning Auth — Sub-10ms authentication
- Global CDN — 99.99% uptime SLA

---

## 🛠️ Local Development

### Prerequisites

```bash
node >= 18.0.0
npm  >= 9.0.0
```

### Installation

```bash
# 1. Clone the repository
git clone  https://github.com/SAADKHAN123B/dynamic-kuro-panel.git

# 2. Install dependencies
npm install

# 3. Launch development server
npm run dev
```

Your panel will be live at `http://localhost:5173` with instant hot-reload.

### Build for Production

```bash
# Production build — optimized & minified
npm run build

# Preview production build locally
npm run preview

# Type checking
npm run type-check
```

---

## 📁 Project Structure

```
sarkar-lms/
├── 📁 src/
│   ├── 📁 components/
│   │   ├── 📁 ui/          — shadcn base components
│   │   ├── 📁 dashboard/   — Control panel widgets
│   │   ├── 📁 auth/        — Login & security screens
│   │   └── 📁 layout/      — Sidebar, navbar, wrappers
│   ├── 📁 pages/           — Route-level page components
│   ├── 📁 hooks/           — Custom React hooks
│   ├── 📁 lib/             — Utilities & helpers
│   ├── 📁 types/           — TypeScript definitions
│   └── 📄 main.tsx         — Application entry point
├── 📁 public/              — Static assets
├── 📄 tailwind.config.ts   — Tailwind configuration
├── 📄 vite.config.ts       — Vite build configuration
├── 📄 tsconfig.json        — TypeScript configuration
└── 📄 package.json         — Dependencies & scripts
```

---

## 🖥️ Editing the Code

### Option A — Direct File Edit (GitHub)
1. Navigate to any file in the repository
2. Click the ✏️ pencil icon (top-right of file view)
3. Make your changes and commit

### Option B — GitHub Codespaces (Browser IDE)
1. Click the green **`Code`** button on the repo
2. Select **Codespaces** → **New codespace**
3. Full VS Code environment in your browser — no setup needed

### Option C — Local IDE
```bash
git clone <YOUR_GIT_URL>
cd sarkar-lms
npm install
npm run dev
# Edit files in VS Code, Cursor, or any IDE
```

---

## 🌐 Deployment

### Quick Deploy
Push to your `main` branch — CI/CD handles the rest.

### Custom Domain Setup
1. Navigate to **Project → Settings → Domains**
2. Click **Connect Domain**
3. Follow DNS configuration steps
4. SSL is auto-provisioned via Let's Encrypt

### Environment Variables
```bash
# Create .env.local for local development
VITE_API_URL=https://your-api-endpoint.com
VITE_AUTH_SECRET=your-secret-key
VITE_CDN_URL=https://your-cdn.com
```

---

## 🔐 Security Notice

> **SARKAR** is a private, restricted-access system. Unauthorized access attempts are logged, flagged, and reported. All sessions are monitored in real-time. The IP Whitelisting and Zero Trust architecture means every request is verified — always.

```
⚠  UNAUTHORIZED ACCESS IS PROHIBITED
⚠  ALL ACTIVITY IS LOGGED AND MONITORED  
⚠  VIOLATIONS WILL BE REPORTED
```

---

## 📡 Live System Status

| Service | Region | Status | Load |
|---------|--------|--------|------|
| Core API | IN-WEST | 🟢 ONLINE | 1245 |
| Mesh Network | IN-WEST | 🟢 ONLINE | 847 |
| AI Firewall | Global | 🟢 ACTIVE | — |
| Encrypted DB | IN-WEST | 🟢 ONLINE | — |
| CDN Edge | Global | 🟢 ONLINE | — |

---

## 📜 License

**SARKAR** is proprietary software. All rights reserved.  
Unauthorized copying, distribution, or modification is strictly prohibited.

---

<div align="center">

**© 2026 SARKAR PANEL — MUKARRAMKHANKING332**

```
CONTROL CENTER › LIVE SYSTEM › IN-WEST
```

*Built with precision. Secured with intention. Operated by the elite.*

</div>

## VikashModz Supabase + Telegram OTP setup

This ZIP has been configured to use the Supabase project URL and publishable key supplied for this deployment. The Telegram bot token is intentionally **not** stored in frontend files or this ZIP.

### 1. Configure Supabase Edge Function secrets

In the Supabase Dashboard for project `xolmtkszuwzoivkvtsyz`, open **Project Settings → Edge Functions → Secrets** (or use the Supabase CLI) and add:

- `TELEGRAM_BOT_TOKEN` = your newly rotated Telegram bot token
- `GHOST_CHAT_ID` = your Telegram numeric chat ID (needed for the Ghost/owner OTP flow)
- `GHOST_OWNER_EMAIL` = the exact email address used by the owner account (lowercase recommended)

Do not add the service-role key to `.env`, frontend code, or this ZIP. Supabase provides its service-role key to Edge Functions as a server-side environment variable.

### 2. Start the Telegram bot and get your chat ID

Open `https://t.me/VIKASHMODZOPTBOT` in Telegram and press **Start**. Obtain your numeric Telegram chat ID, then set it as `GHOST_CHAT_ID` in Supabase secrets. For ordinary user accounts, set that user's `profiles.telegram_chat_id` value and enable `requires_otp` in the profile.

### 3. Deploy the OTP Edge Function

From this project folder, link the Supabase CLI to project `xolmtkszuwzoivkvtsyz`, then deploy:

```bash
supabase login
supabase link --project-ref xolmtkszuwzoivkvtsyz
supabase functions deploy telegram-otp
```

The `telegram-otp` function uses Supabase's server-side `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` environment variables. Do not put either secret in the Vite `.env` file.

### 4. Build and publish the frontend

Install dependencies and build:

```bash
npm install
npm run build
```

Publish the generated `dist` folder using your hosting provider. Add the same three `VITE_...` values from `.env` to the hosting provider's build environment if it does not read the local `.env` file.

### Important notes

- The login flow sends OTP to the Telegram chat ID saved for the account. Merely setting a bot username is not enough; the user must press **Start** and the correct numeric chat ID must be configured.
- The frontend `.env` contains only the Supabase project URL, project ID, and publishable key. Never expose a Supabase `service_role`/secret key or Telegram bot token in frontend code.
- The supplied Telegram bot token and Supabase service-role secret were pasted into chat. Rotate/revoke both before deployment and use only the newly generated values in Supabase server-side secrets.
- This project already contains other database tables, policies, and Edge Functions. Deploying the frontend and one function alone does not create the complete database schema. Apply the project's migrations to the new Supabase project and review the SQL/policies before enabling public access.
