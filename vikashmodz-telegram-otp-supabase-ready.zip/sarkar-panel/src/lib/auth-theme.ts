export type AuthTheme = "blood" | "dark" | "light";

export const AUTH_THEME_ORDER: AuthTheme[] = ["blood", "dark", "light"];

export function getStoredAuthTheme(): AuthTheme {
  if (typeof window === "undefined") {
    return "blood";
  }

  const stored = localStorage.getItem("gta-theme");
  if (stored === "light" || stored === "dark" || stored === "blood") {
    return stored;
  }

  return "blood";
}

export function applyAuthTheme(theme: AuthTheme) {
  if (typeof document === "undefined") {
    return;
  }

  const root = document.documentElement;
  root.classList.remove("dark", "light", "blood");

  if (theme === "blood") {
    root.classList.add("dark", "blood");
    return;
  }

  if (theme === "dark") {
    root.classList.add("dark");
    return;
  }

  root.classList.add("light");
}

export function getNextAuthTheme(theme: AuthTheme): AuthTheme {
  const index = AUTH_THEME_ORDER.indexOf(theme);
  return AUTH_THEME_ORDER[(index + 1) % AUTH_THEME_ORDER.length];
}

export function persistAuthTheme(theme: AuthTheme) {
  if (typeof window !== "undefined") {
    localStorage.setItem("gta-theme", theme);
  }
  applyAuthTheme(theme);
}

export function getAuthThemePalette(theme: AuthTheme) {
  const isBlood = theme === "blood";
  const isDark = theme !== "light";
  const accent = isBlood ? "#ef2b2b" : isDark ? "#006fff" : "#da4e24";
  const accentHover = isBlood ? "#ff6666" : isDark ? "#3388ff" : "#ff6b3d";
  const accentRgb = isBlood ? "239,43,43" : isDark ? "0,111,255" : "218,78,36";
  const surfaceRgb = isBlood ? "36,0,0" : isDark ? "0,18,48" : "36,16,6";

  return {
    theme,
    isBlood,
    isDark,
    accent,
    accentHover,
    accentRgb,
    textPrimary: "rgba(255,255,255,0.88)",
    textSecondary: "rgba(255,255,255,0.48)",
    textMuted: "rgba(255,255,255,0.26)",
    textTertiary: "rgba(255,255,255,0.34)",
    iconMuted: "text-white/25",
    line: `linear-gradient(270deg, transparent 0%, rgba(${accentRgb},0.7) 50%, transparent 100%)`,
    softLine: `linear-gradient(270deg, transparent 0%, rgba(${accentRgb},0.45) 50%, transparent 100%)`,
    pageGlow: isBlood
      ? `radial-gradient(ellipse at 20% 10%, rgba(${accentRgb},0.14) 0%, transparent 50%), linear-gradient(180deg, rgb(18,0,0) 0%, rgb(0,0,0) 100%)`
      : isDark
        ? `radial-gradient(ellipse at 20% 10%, rgba(${accentRgb},0.12) 0%, transparent 50%), linear-gradient(180deg, rgb(0,12,36) 0%, rgb(0,0,0) 100%)`
        : `radial-gradient(ellipse at 30% 20%, rgba(${accentRgb},0.15) 0%, transparent 50%), linear-gradient(180deg, rgb(12,8,4) 0%, rgb(0,0,0) 100%)`,
    chipBackground: isDark
      ? "linear-gradient(180deg, rgba(255,255,255,0.1) 0%, rgba(0,0,0,0) 100%)"
      : "linear-gradient(180deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0.62) 100%)",
    chipBorder: isDark ? "rgba(255,255,255,0.1)" : `rgba(${accentRgb},0.18)`,
    chipShadow: isDark ? `inset 0 0 9px rgba(${accentRgb},0.1)` : `0 2px 12px rgba(${accentRgb},0.12)`,
    dotShadow: `0 0 8px rgba(${accentRgb},0.8)`,
    cardBg: "linear-gradient(180deg, rgba(255,255,255,0.06) 0%, rgba(0,0,0,0.4) 100%)",
    cardBorder: `rgba(${accentRgb},0.16)`,
    cardShadow: `inset 0 0 48px rgba(${accentRgb},0.08), inset 0 1px 0 rgba(255,255,255,0.06), 0 20px 60px rgba(0,0,0,0.5), 0 8px 16px rgba(${accentRgb},0.1)`,
    inputBg: "rgba(255,255,255,0.04)",
    inputBorder: "rgba(255,255,255,0.08)",
    buttonBg: isDark ? "black" : accent,
    buttonBorder: `rgba(${accentRgb},${isDark ? "0.5" : "0.82"})`,
    buttonShadow: isDark
      ? `inset 0 0 36px rgba(${accentRgb},0.2), 0 8px 16px rgba(${accentRgb},0.15)`
      : `0 8px 24px rgba(${accentRgb},0.3)`,
    buttonOverlay: isDark
      ? `linear-gradient(180deg, transparent 0%, rgba(${accentRgb},0.5) 100%)`
      : `linear-gradient(180deg, rgba(255,255,255,0.12) 0%, rgba(${accentRgb},0.15) 100%)`,
    iconPanelBg: `rgba(${surfaceRgb},0.82)`,
    iconPanelBorder: `rgba(${accentRgb},0.3)`,
    iconPanelShadow: `inset 0 0 29px rgba(${accentRgb},0.26), 0 0 30px rgba(${accentRgb},0.18)`,
    successPanelBg: `rgba(${accentRgb},0.08)`,
    successPanelBorder: `rgba(${accentRgb},0.2)`,
    successPanelShadow: `inset 0 0 30px rgba(${accentRgb},0.15)`,
    subtleButtonBg: `rgba(${accentRgb},0.09)`,
    subtleButtonBorder: `rgba(${accentRgb},0.2)`,
    footerAccent: `${accent}50`,
  };
}