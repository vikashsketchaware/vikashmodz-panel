import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Download, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import jsPDF from "jspdf";

interface Order {
  id: string;
  bot_id: string;
  telegram_user_id: number;
  telegram_username: string | null;
  amount: number;
  currency: string;
  status: string;
  payment_mode: string;
  payment_provider: string | null;
  provider_order_id: string | null;
  provider_payment_id: string | null;
  coupon_code: string | null;
  duration_hours: number | null;
  delivered_key_id: string | null;
  created_at: string;
  bot_name?: string;
  key_code?: string;
}

const statusVariant = (s: string): "default" | "secondary" | "destructive" | "outline" => {
  if (s === "delivered" || s === "paid") return "default";
  if (s === "pending") return "secondary";
  if (s === "failed" || s === "refunded") return "destructive";
  return "outline";
};

const BotOrders = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("bot_orders")
      .select(`*, telegram_bots(name, display_name), license_keys(key_code)`)
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) {
      toast.error("Failed to load orders");
      setLoading(false);
      return;
    }
    const mapped = (data || []).map((o: any) => ({
      ...o,
      bot_name: o.telegram_bots?.display_name || o.telegram_bots?.name,
      key_code: o.license_keys?.key_code,
    }));
    setOrders(mapped);
    setLoading(false);
  };

  useEffect(() => {
    load();
    const channel = supabase
      .channel("bot_orders_changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "bot_orders" }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const generateInvoice = (o: Order) => {
    const doc = new jsPDF();
    const pageW = doc.internal.pageSize.getWidth();

    // Header
    doc.setFillColor(15, 23, 42);
    doc.rect(0, 0, pageW, 35, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(22);
    doc.setFont("helvetica", "bold");
    doc.text("INVOICE", 14, 22);
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(o.bot_name || "Key Reseller", pageW - 14, 22, { align: "right" });

    doc.setTextColor(0, 0, 0);
    doc.setFontSize(11);
    let y = 50;
    doc.setFont("helvetica", "bold");
    doc.text("Order ID:", 14, y);
    doc.setFont("helvetica", "normal");
    doc.text(o.id, 50, y);
    y += 7;
    doc.setFont("helvetica", "bold");
    doc.text("Date:", 14, y);
    doc.setFont("helvetica", "normal");
    doc.text(new Date(o.created_at).toLocaleString("en-IN"), 50, y);
    y += 7;
    doc.setFont("helvetica", "bold");
    doc.text("Buyer:", 14, y);
    doc.setFont("helvetica", "normal");
    doc.text(`${o.telegram_username ? "@" + o.telegram_username : ""} (TG: ${o.telegram_user_id})`, 50, y);
    y += 7;
    doc.setFont("helvetica", "bold");
    doc.text("Status:", 14, y);
    doc.setFont("helvetica", "normal");
    doc.text(o.status.toUpperCase(), 50, y);

    // Items table
    y += 15;
    doc.setFillColor(241, 245, 249);
    doc.rect(14, y, pageW - 28, 9, "F");
    doc.setFont("helvetica", "bold");
    doc.text("Item", 18, y + 6);
    doc.text("Mode", 100, y + 6);
    doc.text("Amount", pageW - 18, y + 6, { align: "right" });
    y += 14;
    doc.setFont("helvetica", "normal");
    doc.text(`License Key — ${o.duration_hours || 0}h`, 18, y);
    doc.text(o.payment_mode.toUpperCase(), 100, y);
    doc.text(`Rs. ${Number(o.amount).toFixed(2)}`, pageW - 18, y, { align: "right" });

    if (o.coupon_code) {
      y += 7;
      doc.setTextColor(100, 100, 100);
      doc.text(`Coupon applied: ${o.coupon_code}`, 18, y);
      doc.setTextColor(0, 0, 0);
    }

    // Total
    y += 15;
    doc.setDrawColor(15, 23, 42);
    doc.line(14, y, pageW - 14, y);
    y += 8;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(13);
    doc.text("TOTAL", 18, y);
    doc.text(`Rs. ${Number(o.amount).toFixed(2)} ${o.currency}`, pageW - 18, y, { align: "right" });

    // Payment / key info
    y += 15;
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    if (o.provider_payment_id) doc.text(`Payment ID: ${o.provider_payment_id}`, 14, y);
    if (o.key_code) {
      y += 6;
      doc.text(`License Key: ${o.key_code}`, 14, y);
    }

    doc.setFontSize(9);
    doc.setTextColor(120, 120, 120);
    doc.text("Thank you for your purchase.", pageW / 2, 280, { align: "center" });

    doc.save(`invoice-${o.id.slice(0, 8)}.pdf`);
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Bot Orders</h1>
          <p className="text-sm text-muted-foreground">Real-time order list across all selling bots.</p>
        </div>
        <Button onClick={load} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-2" /> Refresh
        </Button>
      </div>

      <Card className="overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Bot</TableHead>
              <TableHead>Buyer</TableHead>
              <TableHead>Plan</TableHead>
              <TableHead>Mode</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Invoice</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : orders.length === 0 ? (
              <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No orders yet.</TableCell></TableRow>
            ) : orders.map(o => (
              <TableRow key={o.id}>
                <TableCell className="text-xs whitespace-nowrap">{new Date(o.created_at).toLocaleString("en-IN")}</TableCell>
                <TableCell className="text-xs">{o.bot_name || "-"}</TableCell>
                <TableCell className="text-xs">{o.telegram_username ? `@${o.telegram_username}` : o.telegram_user_id}</TableCell>
                <TableCell className="text-xs">{o.duration_hours}h</TableCell>
                <TableCell><Badge variant="outline" className="text-xs">{o.payment_mode}</Badge></TableCell>
                <TableCell className="font-mono text-xs">₹{Number(o.amount).toFixed(2)}</TableCell>
                <TableCell><Badge variant={statusVariant(o.status)} className="text-xs">{o.status}</Badge></TableCell>
                <TableCell>
                  <Button size="sm" variant="ghost" onClick={() => generateInvoice(o)}>
                    <Download className="h-3.5 w-3.5" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
};

export default BotOrders;