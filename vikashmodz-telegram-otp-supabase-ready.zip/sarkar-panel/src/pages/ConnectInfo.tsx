import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

const SUPABASE_BASE = import.meta.env.VITE_SUPABASE_URL;

const ConnectInfo = () => {
  const location = useLocation();
  const isSdk = location.pathname.startsWith("/sdk/connect");
  const [copied, setCopied] = useState(false);

  const endpoint = isSdk
    ? `${SUPABASE_BASE}/functions/v1/sarkar-api/sdk/panel/connect`
    : `${SUPABASE_BASE}/functions/v1/sarkar-api/connect`;

  useEffect(() => {
    document.title = isSdk ? "SDK Connect Endpoint" : "Connect Endpoint";
  }, [isSdk]);

  const copy = async () => {
    await navigator.clipboard.writeText(endpoint);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="min-h-svh flex items-center justify-center bg-background text-foreground p-6">
      <div className="max-w-xl w-full space-y-6 rounded-2xl border border-border bg-card/60 backdrop-blur p-8">
        <div className="text-center space-y-2">
          <div className="text-5xl">{isSdk ? "🛡️" : "🔌"}</div>
          <h1 className="text-2xl font-bold tracking-tight">
            {isSdk ? "SDK Connect Endpoint" : "Client Connect Endpoint"}
          </h1>
          <p className="text-sm text-muted-foreground">
            This is a POST-only API endpoint. Use it from your native client (C++/Java/Android).
          </p>
        </div>

        <div className="space-y-2">
          <label className="text-xs uppercase tracking-wider text-muted-foreground">Endpoint URL</label>
          <div className="flex items-stretch gap-2">
            <code className="flex-1 px-3 py-2 rounded-md bg-muted text-xs break-all">{endpoint}</code>
            <button onClick={copy} className="px-3 py-2 rounded-md bg-primary text-primary-foreground text-xs font-medium hover:opacity-90">
              {copied ? "Copied" : "Copy"}
            </button>
          </div>
        </div>

        <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-3 text-xs text-amber-200">
          ⚠️ This panel URL serves the dashboard. The actual API runs on the secured edge function above. Hardcode that URL in your native client.
        </div>

        <div className="text-xs text-muted-foreground">
          Method: <span className="text-foreground font-mono">POST</span> · Content-Type: <span className="text-foreground font-mono">application/json</span>
        </div>
      </div>
    </div>
  );
};

export default ConnectInfo;