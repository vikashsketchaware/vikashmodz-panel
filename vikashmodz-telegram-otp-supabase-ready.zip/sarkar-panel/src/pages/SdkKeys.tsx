import { useEffect, useState } from "react";
import { Cpu, Copy, Download, Loader2, Gamepad2, Code2, Package, Check } from "lucide-react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

interface Game { id: string; name: string; icon_url: string | null; }
interface PriceSetting { duration_hours: number; price: number; }

const SDK_ENDPOINT =
  "https://xolmtkszuwzoivkvtsyz.supabase.co/functions/v1/sarkar-api/sdk/panel/connect";

// Java source the user drops into  app/src/main/java/net_62v/external/MetaActivationManager.java
const JAVA_SOURCE = `package net_62v.external;

import android.util.Log;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * MetaActivationManager
 * Validates SDK key + host package against the panel before allowing the
 * virtual container to boot. Drop this file at:
 *   app/src/main/java/net_62v/external/MetaActivationManager.java
 *
 * Usage (already in BoxApplication.onCreate):
 *   MetaActivationManager.activateSdk("YOUR-SDK-KEY");
 */
public final class MetaActivationManager {
    private static final String TAG = "MetaSDK";
    private static final String ENDPOINT =
        "${SDK_ENDPOINT}";
    private static final String API_KEY =
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV0emNoY2l1dGNrYndyZXJvYWhnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA0MzE4NDAsImV4cCI6MjA4NjAwNzg0MH0.7bdF2X55vEuZTWb5gdlk1mBcv3Y4e_Kk8wcCkVaZPNs";

    private MetaActivationManager() {}

    public static void activateSdk(String sdkKey) {
        try {
            String pkg = top.niunaijun.blackbox.BlackBoxCore.get()
                .getContext().getPackageName();

            URL url = new URL(ENDPOINT);
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("apikey", API_KEY);
            c.setRequestProperty("User-Agent", "Dalvik/2.1.0 (Android SDK)");
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setDoOutput(true);

            String body = "{\\"user_key\\":\\"" + sdkKey
                + "\\",\\"package_name\\":\\"" + pkg + "\\"}";
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.getBytes("UTF-8"));
            }

            int code = c.getResponseCode();
            BufferedReader r = new BufferedReader(new InputStreamReader(
                code >= 400 ? c.getErrorStream() : c.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line; while ((line = r.readLine()) != null) sb.append(line);
            r.close();

            JSONObject json = new JSONObject(sb.toString());
            if (!json.optBoolean("status", false)) {
                Log.e(TAG, "SDK activation rejected: " + json.optString("reason"));
                kill();
                return;
            }
            Log.i(TAG, "SDK activated OK");
        } catch (Exception e) {
            Log.e(TAG, "SDK activation error", e);
            kill();
        }
    }

    private static void kill() {
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(10);
    }
}
`;

const SdkKeys = () => {
  const { user, profile, role, refreshProfile } = useAuth();
  const { toast } = useToast();

  const [games, setGames] = useState<Game[]>([]);
  const [selectedGame, setSelectedGame] = useState<string>("");
  const [prices, setPrices] = useState<PriceSetting[]>([]);
  const [duration, setDuration] = useState<string>("24");
  const [quantity, setQuantity] = useState<string>("1");
  const [useCustomKey, setUseCustomKey] = useState(false);
  const [customKeyCode, setCustomKeyCode] = useState("");
  const [generatedKeys, setGeneratedKeys] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedJava, setCopiedJava] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("games").select("id, name, icon_url").eq("status", "active");
      const list = data || [];
      setGames(list);
      const pubg = list.find((g) => g.name.toUpperCase() === "PUBG");
      if (pubg) setSelectedGame(pubg.id);
      else if (list[0]) setSelectedGame(list[0].id);
    })();
  }, []);

  useEffect(() => {
    if (!selectedGame) return;
    (async () => {
      const { data } = await supabase.rpc("get_game_prices", { p_game_id: selectedGame });
      const arr = ((data as unknown) as PriceSetting[]) || [];
      setPrices(arr);
      if (arr.length > 0) setDuration(arr[0].duration_hours.toString());
    })();
  }, [selectedGame]);

  const formatDuration = (hours: number) => {
    if (hours < 24) return `${hours}h`;
    const d = hours / 24;
    if (d < 30) return `${d}d`;
    const m = Math.round(d / 30);
    if (m < 12) return `${m}mo`;
    return `${Math.round(d / 365)}y`;
  };

  const randomKey = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789";
    const seg = () => Array.from({ length: 4 },
      () => chars[Math.floor(Math.random() * chars.length)]).join("");
    // SDK keys are prefixed with `sdk-` so they are visually distinct from normal keys
    return `sdk-${[seg(), seg(), seg(), seg()].join("-")}`;
  };

  const calcPrice = () => {
    const p = prices.find((x) => x.duration_hours === parseInt(duration))?.price || 0;
    return p * parseInt(quantity || "1");
  };

  const handleGenerate = async () => {
    if (!selectedGame || !user) {
      toast({ title: "Select a game", variant: "destructive" });
      return;
    }
    if (useCustomKey) {
      const t = customKeyCode.trim();
      if (t.length < 3 || !/^[A-Za-z0-9_-]+$/.test(t)) {
        toast({ title: "Invalid key", description: "Min 3 chars, letters/numbers/-/_", variant: "destructive" });
        return;
      }
    }
    const total = calcPrice();
    if (profile && profile.balance < total && role !== "owner" && role !== "co_owner") {
      toast({ title: "Insufficient balance", description: `Need ₹${total.toFixed(2)}`, variant: "destructive" });
      return;
    }
    setIsGenerating(true);
    try {
      const n = useCustomKey ? 1 : parseInt(quantity || "1");
      const keys = useCustomKey
        ? [customKeyCode.trim().toUpperCase()]
        : Array.from({ length: n }, () => randomKey());

      const { data, error } = await supabase.functions.invoke("admin-actions", {
        body: {
          action: "generate_keys",
          game_id: selectedGame,
          duration_hours: parseInt(duration),
          keys,
          // SDK keys: no real device cap (host package is the gate)
          max_devices: 99999,
          package_restricted: true,
        },
      });
      if (error || (data as any)?.error) {
        throw new Error((data as any)?.error || error?.message || "Failed");
      }
      setGeneratedKeys(keys);
      setCustomKeyCode("");
      await refreshProfile();
      toast({ title: "SDK Keys generated", description: `${keys.length} key(s) created` });
    } catch (e: any) {
      toast({ title: "Error", description: e?.message || "Failed", variant: "destructive" });
    } finally {
      setIsGenerating(false);
    }
  };

  const copyKeys = () => {
    navigator.clipboard.writeText(generatedKeys.join("\n"));
    toast({ title: "Copied" });
  };

  const downloadKeys = () => {
    const blob = new Blob([generatedKeys.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `sdk-keys-${Date.now()}.txt`; a.click();
    URL.revokeObjectURL(url);
  };

  const copyJava = async () => {
    await navigator.clipboard.writeText(JAVA_SOURCE);
    setCopiedJava(true);
    toast({ title: "Java source copied" });
    setTimeout(() => setCopiedJava(false), 2000);
  };

  const downloadJava = () => {
    const blob = new Blob([JAVA_SOURCE], { type: "text/x-java-source" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "MetaActivationManager.java"; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
            <Cpu className="h-8 w-8 text-primary" />
            SDK Keys
          </h1>
          <p className="text-muted-foreground">
            Time-based keys for the Android virtual-container SDK. Bound to approved package names — no device cap.
          </p>
        </div>

        <Tabs defaultValue="generate" className="space-y-4">
          <TabsList className="glass-card">
            <TabsTrigger value="generate">Generate</TabsTrigger>
            <TabsTrigger value="integration">Java Integration</TabsTrigger>
          </TabsList>

          {/* GENERATE */}
          <TabsContent value="generate" className="space-y-6">
            <div className="glass-card-glow p-6 rounded-xl space-y-4">
              <div className="space-y-2">
                <Label className="text-muted-foreground">Game</Label>
                <Select value={selectedGame} onValueChange={setSelectedGame}>
                  <SelectTrigger className="input-dark">
                    <SelectValue placeholder="Select game">
                      {selectedGame && (
                        <div className="flex items-center gap-2">
                          <Avatar className="h-5 w-5">
                            <AvatarImage src={games.find((g) => g.id === selectedGame)?.icon_url || undefined} />
                            <AvatarFallback className="bg-primary/10">
                              <Gamepad2 className="h-3 w-3 text-primary" />
                            </AvatarFallback>
                          </Avatar>
                          <span>{games.find((g) => g.id === selectedGame)?.name}</span>
                        </div>
                      )}
                    </SelectValue>
                  </SelectTrigger>
                  <SelectContent className="glass-card border-border/50">
                    {games.map((g) => (
                      <SelectItem key={g.id} value={g.id}>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-5 w-5">
                            <AvatarImage src={g.icon_url || undefined} />
                            <AvatarFallback className="bg-primary/10">
                              <Gamepad2 className="h-3 w-3 text-primary" />
                            </AvatarFallback>
                          </Avatar>
                          <span>{g.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex flex-col gap-3 p-4 glass-card rounded-lg sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <Label className="text-foreground">Use Custom Key</Label>
                  <p className="text-xs text-muted-foreground">Enter your own key string instead of random</p>
                </div>
                <Switch checked={useCustomKey} onCheckedChange={(v) => { setUseCustomKey(v); if (v) setQuantity("1"); }} />
              </div>

              {useCustomKey && (
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Custom Key Code</Label>
                  <Input
                    placeholder="WJVL-KXXV-B2TK-C0JU"
                    value={customKeyCode}
                    onChange={(e) => setCustomKeyCode(e.target.value.toUpperCase())}
                    className="input-dark font-mono tracking-wider"
                    maxLength={50}
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Duration (time limit)</Label>
                  <Select value={duration} onValueChange={setDuration} disabled={prices.length === 0}>
                    <SelectTrigger className="input-dark"><SelectValue /></SelectTrigger>
                    <SelectContent className="glass-card border-border/50">
                      {prices.map((p) => (
                        <SelectItem key={p.duration_hours} value={p.duration_hours.toString()}>
                          {formatDuration(p.duration_hours)} — ₹{p.price.toFixed(2)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {selectedGame && prices.length === 0 && (
                    <p className="text-xs text-destructive">No prices configured for this game</p>
                  )}
                </div>

                {!useCustomKey && (
                  <div className="space-y-2">
                    <Label className="text-muted-foreground">Quantity</Label>
                    <Input
                      type="number" min="1" max="100"
                      value={quantity} onChange={(e) => setQuantity(e.target.value)}
                      className="input-dark"
                    />
                  </div>
                )}
              </div>

              <div className="flex items-start gap-2 p-3 glass-card rounded-lg border border-primary/20 text-xs text-muted-foreground">
                <Package className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <span>
                  SDK keys are <b>package-locked</b>. Add the host Android package(s) under{" "}
                  <b>SDK Packages</b> before distributing keys. No device limit applies.
                </span>
              </div>

              <div className="p-4 glass-card rounded-lg flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <span className="text-muted-foreground">Total:</span>
                <span className="text-2xl font-bold gradient-text stats-value">₹{calcPrice().toFixed(2)}</span>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={isGenerating || !selectedGame || prices.length === 0}
                className="w-full h-11 bg-gradient-to-r from-primary to-accent text-primary-foreground"
              >
                {isGenerating
                  ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Generating...</>
                  : <>Generate SDK Keys</>}
              </Button>
            </div>

            {generatedKeys.length > 0 && (
              <div className="glass-card-glow p-6 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-foreground">Generated ({generatedKeys.length})</h3>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={copyKeys}>
                      <Copy className="h-3.5 w-3.5 mr-1.5" />Copy
                    </Button>
                    <Button size="sm" variant="outline" onClick={downloadKeys}>
                      <Download className="h-3.5 w-3.5 mr-1.5" />Save
                    </Button>
                  </div>
                </div>
                <div className="font-mono text-sm space-y-1 max-h-72 overflow-auto">
                  {generatedKeys.map((k) => (
                    <div key={k} className="px-3 py-2 bg-muted/30 rounded border border-border/40 break-all">
                      {k}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          {/* INTEGRATION */}
          <TabsContent value="integration" className="space-y-4">
            <div className="glass-card-glow p-6 rounded-xl space-y-4">
              <div className="flex items-center gap-2">
                <Code2 className="h-5 w-5 text-primary" />
                <h3 className="font-semibold text-foreground">MetaActivationManager.java</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Drop this file at <code className="text-primary">app/src/main/java/net_62v/external/MetaActivationManager.java</code>.
                Fixes the build error <code>package net_62v.external does not exist</code> and
                makes <code>MetaActivationManager.activateSdk("KEY")</code> verify against the panel
                before BlackBox boots. On rejection the host process is killed.
              </p>
              <div className="flex gap-2">
                <Button size="sm" onClick={copyJava}>
                  {copiedJava ? <><Check className="h-3.5 w-3.5 mr-1.5" />Copied</> : <><Copy className="h-3.5 w-3.5 mr-1.5" />Copy Java</>}
                </Button>
                <Button size="sm" variant="outline" onClick={downloadJava}>
                  <Download className="h-3.5 w-3.5 mr-1.5" />Download .java
                </Button>
              </div>
              <pre className="text-xs bg-muted/30 border border-border/40 rounded-lg p-4 overflow-auto max-h-[480px] font-mono leading-relaxed">
{JAVA_SOURCE}
              </pre>
              <div className="text-xs text-muted-foreground space-y-1 pt-2 border-t border-border/30">
                <p><b>Endpoint:</b> <code>{SDK_ENDPOINT}</code></p>
                <p><b>Request:</b> <code>{`{ "user_key": "...", "package_name": "..." }`}</code></p>
                <p><b>Success:</b> <code>{`{ "status": true, "data": { ... } }`}</code></p>
                <p><b>Reject:</b> <code>{`{ "status": false, "reason": "INVALID_REQUEST" }`}</code> → SDK kills the process.</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
};

export default SdkKeys;