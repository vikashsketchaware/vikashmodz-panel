import { useEffect, useState, type CSSProperties } from "react";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Mail, ArrowLeft, CheckCircle, KeyRound, ArrowRight, Sun, Moon, Droplet } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import AuthBackground from "@/components/AuthBackground";
import { motion } from "framer-motion";
import { applyAuthTheme, getAuthThemePalette, getNextAuthTheme, getStoredAuthTheme, persistAuthTheme, type AuthTheme } from "@/lib/auth-theme";

const forgotPasswordSchema = z.object({
  email: z.string().email("Invalid email address"),
});

type ForgotPasswordForm = z.infer<typeof forgotPasswordSchema>;

const ForgotPassword = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const [theme, setTheme] = useState<AuthTheme>(() => getStoredAuthTheme());
  const { toast } = useToast();
  const palette = getAuthThemePalette(theme);

  useEffect(() => {
    applyAuthTheme(theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => {
      const next = getNextAuthTheme(prev);
      persistAuthTheme(next);
      return next;
    });
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ForgotPasswordForm>({
    resolver: zodResolver(forgotPasswordSchema),
  });

  const onSubmit = async (data: ForgotPasswordForm) => {
    setIsLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(data.email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) {
        toast({ title: "Error", description: error.message, variant: "destructive" });
      } else {
        setEmailSent(true);
        toast({ title: "Email Sent!", description: "Check your inbox for the password reset link." });
      }
    } catch (err) {
      toast({ title: "Error", description: "An unexpected error occurred.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-black">
      <AuthBackground theme={theme} />

      <motion.button
        className="fixed top-5 right-5 z-50 flex h-10 w-10 items-center justify-center rounded-xl transition-all"
        style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)' }}
        onClick={toggleTheme}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.95 }}
      >
        {theme === "blood" ? <Droplet className="h-4 w-4" style={{ color: palette.accent, fill: palette.accent }} /> : theme === "dark" ? <Sun className="h-4 w-4" style={{ color: 'rgba(255,255,255,0.7)' }} /> : <Moon className="h-4 w-4" style={{ color: 'rgba(255,255,255,0.7)' }} />}
      </motion.button>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4">
        {/* Brand */}
        <motion.div
          className="mb-10 text-center"
          initial={{ opacity: 0.001, y: -150 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, ease: [0.25, 0.46, 0.45, 0.94] }}
        >
          <motion.div
            className="inline-flex items-center gap-2 px-5 py-2 rounded-full mb-6 relative"
            style={{ background: palette.chipBackground, border: `1px solid ${palette.chipBorder}`, boxShadow: palette.chipShadow }}
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
          >
            <div className="absolute top-0 left-[20%] right-[20%] h-[1px]" style={{
              background: palette.softLine,
            }} />
            <div className="w-1.5 h-1.5 rounded-full" style={{ background: palette.accent, boxShadow: palette.dotShadow }} />
            <span className="text-xs font-medium tracking-wider" style={{ color: palette.textPrimary, fontFamily: "'DM Sans', 'Inter', sans-serif" }}>
              Account Recovery
            </span>
          </motion.div>

          <motion.h1
            className="text-5xl md:text-7xl font-black tracking-tight"
            style={{
              fontFamily: "'Bebas Neue', 'Orbitron', sans-serif",
              backgroundImage: palette.isDark ? 'linear-gradient(0deg, rgba(255,255,255,0.5) 0%, rgb(255,255,255) 100%)' : `linear-gradient(0deg, ${palette.accent} 0%, rgba(0,0,0,0.85) 100%)`,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
            initial={{ opacity: 0.001, y: 150 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 1.0, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            SARKAR
          </motion.h1>

          <motion.div
            className="mx-auto mt-3 h-[1px] w-40"
            style={{
              background: palette.line,
              boxShadow: `0 0 10px rgba(${palette.accentRgb},0.3)`,
            }}
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.8, duration: 0.8 }}
          />
        </motion.div>

        {/* Card */}
        <motion.div
          className="w-full max-w-[420px]"
          initial={{ opacity: 0.001, y: 150 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }}
        >
          <div
            className="relative rounded-2xl p-8 md:p-10"
            style={{
              background: palette.cardBg,
              border: `1px solid ${palette.cardBorder}`,
              boxShadow: palette.cardShadow,
              backdropFilter: 'blur(20px)',
            }}
          >
            <motion.div
              className="absolute top-0 left-[10%] right-[10%] h-[1px]"
              style={{ background: palette.line }}
              initial={{ opacity: 0, scaleX: 0 }}
              animate={{ opacity: 1, scaleX: 1 }}
              transition={{ delay: 1.2, duration: 0.8 }}
            />

            {/* Back button */}
            <Link
              to="/login"
              className="group mb-6 inline-flex items-center text-sm transition-colors"
              style={{ color: palette.textSecondary, fontFamily: "'DM Sans', sans-serif" }}
            >
              <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
              Back to login
            </Link>

            {/* Icon */}
            <div className="text-center mb-6">
              <motion.div
                className="w-16 h-16 mx-auto mb-4 rounded-2xl flex items-center justify-center"
                style={{
                  background: palette.iconPanelBg,
                  border: `1px solid ${palette.iconPanelBorder}`,
                  boxShadow: palette.iconPanelShadow,
                }}
                animate={{
                  boxShadow: [
                    palette.iconPanelShadow,
                    `inset 0 0 40px rgba(${palette.accentRgb},0.32), 0 0 50px rgba(${palette.accentRgb},0.3)`,
                    palette.iconPanelShadow,
                  ],
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <KeyRound className="h-8 w-8" style={{ color: palette.accent }} />
              </motion.div>
              <h2 className="text-xl font-semibold" style={{ color: palette.textPrimary, fontFamily: "'DM Sans', 'Inter', sans-serif" }}>
                Reset Password
              </h2>
              <p className="mt-1 text-xs" style={{ color: palette.textMuted, fontFamily: "'DM Sans', sans-serif" }}>
                {emailSent ? "Check your email for the reset link" : "Enter your email to receive a reset link"}
              </p>
            </div>

            {!emailSent ? (
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
                <motion.div initial={{ opacity: 0, x: -15 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.8, duration: 0.4 }}>
                  <label className="mb-2 block text-xs font-medium uppercase tracking-[0.15em]" style={{ color: palette.textSecondary, fontFamily: "'DM Sans', sans-serif" }}>
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className={`absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 ${palette.iconMuted}`} />
                    <input
                      {...register("email")}
                      type="email"
                      placeholder="your@email.com"
                      className="w-full h-12 rounded-xl pl-11 pr-4 text-sm text-white placeholder:text-white/20 outline-none transition-all focus:ring-1"
                      style={{
                        background: palette.inputBg,
                        border: `1px solid ${palette.inputBorder}`,
                        '--tw-ring-color': `rgba(${palette.accentRgb},0.4)`,
                        fontFamily: "'DM Sans', 'Inter', sans-serif",
                      } as CSSProperties}
                    />
                  </div>
                  {errors.email && <p className="text-xs text-red-400 mt-1.5">{errors.email.message}</p>}
                </motion.div>

                <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9, duration: 0.4 }}>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="relative w-full h-12 rounded-2xl font-semibold text-sm text-white overflow-hidden group transition-all disabled:opacity-50"
                    style={{
                      background: palette.buttonBg,
                      border: `1px solid ${palette.buttonBorder}`,
                      boxShadow: palette.buttonShadow,
                      fontFamily: "'DM Sans', 'Inter', sans-serif",
                    }}
                  >
                    <div className="absolute inset-0 rounded-2xl opacity-20" style={{ background: palette.buttonOverlay }} />
                    <motion.div className="absolute top-0 left-[15%] right-[15%] h-[1px]" style={{
                      background: palette.line,
                    }} />
                    <span className="relative z-10 flex items-center justify-center gap-2">
                      {isLoading ? (
                        <motion.div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full" animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} />
                      ) : (
                        <>Send Reset Link <ArrowRight className="h-4 w-4" /></>
                      )}
                    </span>
                  </button>
                </motion.div>
              </form>
            ) : (
              <div className="text-center space-y-5">
                <motion.div
                  className="p-6 rounded-xl"
                  style={{
                    background: palette.successPanelBg,
                    border: `1px solid ${palette.successPanelBorder}`,
                    boxShadow: palette.successPanelShadow,
                  }}
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", damping: 15 }}
                >
                  <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 2, repeat: Infinity }}>
                    <CheckCircle className="mx-auto mb-4 h-14 w-14" style={{ color: palette.accent }} />
                  </motion.div>
                  <p className="text-lg font-medium" style={{ color: palette.accent }}>Email Sent Successfully!</p>
                  <p className="mt-2 text-sm" style={{ color: palette.textSecondary }}>Check your inbox and follow the link.</p>
                </motion.div>
                <button
                  onClick={() => setEmailSent(false)}
                  className="h-12 w-full rounded-2xl text-sm font-semibold text-white/60 transition-all hover:text-white"
                  style={{
                    background: palette.subtleButtonBg,
                    border: `1px solid ${palette.subtleButtonBorder}`,
                    fontFamily: "'DM Sans', sans-serif",
                  }}
                >
                  Send Again
                </button>
              </div>
            )}
          </div>
        </motion.div>

        {/* Footer */}
        <motion.div className="mt-10 text-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.4 }}>
          <p className="text-xs tracking-[0.3em] uppercase" style={{ color: 'rgba(255,255,255,0.15)', fontFamily: "'DM Sans', sans-serif" }}>© 2026 SARKAR PANEL</p>
          <p className="mt-1 text-[10px] tracking-[0.3em] uppercase" style={{ color: palette.footerAccent, fontFamily: "'DM Sans', sans-serif" }}>Premium Edition</p>
        </motion.div>
      </div>
    </div>
  );
};

export default ForgotPassword;
