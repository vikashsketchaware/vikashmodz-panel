import { useEffect, useState } from "react";
import { Package, Plus, Trash2, Loader2, Gamepad2, Power } from "lucide-react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

interface Game { id: string; name: string; }
interface Pkg {
  id: string;
  package_name: string;
  game_id: string | null;
  is_active: boolean;
  created_at: string;
}

const SdkPackages = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [games, setGames] = useState<Game[]>([]);
  const [pkgs, setPkgs] = useState<Pkg[]>([]);
  const [loading, setLoading] = useState(true);
  const [pkgName, setPkgName] = useState("");
  const [gameId, setGameId] = useState<string>("ALL");
  const [adding, setAdding] = useState(false);

  const load = async () => {
    setLoading(true);
    const [{ data: g }, { data: p }] = await Promise.all([
      supabase.from("games").select("id, name").eq("status", "active").order("name"),
      supabase.from("approved_packages").select("*").order("created_at", { ascending: false }),
    ]);
    setGames(g || []);
    setPkgs((p as Pkg[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const validPkg = (s: string) => /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$/i.test(s.trim());

  const add = async () => {
    if (!user) return;
    const trimmed = pkgName.trim();
    if (!validPkg(trimmed)) {
      toast({ title: "Invalid package name", description: "Use Android format e.g. com.example.app", variant: "destructive" });
      return;
    }
    setAdding(true);
    const { error } = await supabase.from("approved_packages").insert({
      package_name: trimmed,
      game_id: gameId === "ALL" ? null : gameId,
      created_by: user.id,
      is_active: true,
    });
    setAdding(false);
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
      return;
    }
    setPkgName("");
    toast({ title: "Added", description: "Package approved" });
    load();
  };

  const toggle = async (p: Pkg) => {
    const { error } = await supabase.from("approved_packages").update({ is_active: !p.is_active }).eq("id", p.id);
    if (error) return toast({ title: "Error", description: error.message, variant: "destructive" });
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this package?")) return;
    const { error } = await supabase.from("approved_packages").delete().eq("id", id);
    if (error) return toast({ title: "Error", description: error.message, variant: "destructive" });
    load();
  };

  const gameName = (id: string | null) =>
    id ? (games.find((g) => g.id === id)?.name || "Unknown") : "All Games";

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
            <Package className="h-8 w-8 text-primary" />
            SDK Packages
          </h1>
          <p className="text-muted-foreground">
            Approved Android package names allowed to use SDK keys
          </p>
        </div>

        <div className="glass-card-glow p-6 rounded-xl space-y-4">
          <div className="grid gap-4 md:grid-cols-[1fr_240px_auto]">
            <div className="space-y-2">
              <Label className="text-muted-foreground">Package Name</Label>
              <Input
                placeholder="com.example.app"
                value={pkgName}
                onChange={(e) => setPkgName(e.target.value)}
                className="input-dark font-mono"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground">Game</Label>
              <Select value={gameId} onValueChange={setGameId}>
                <SelectTrigger className="input-dark"><SelectValue /></SelectTrigger>
                <SelectContent className="glass-card border-border/50">
                  <SelectItem value="ALL">All Games (global)</SelectItem>
                  {games.map((g) => (
                    <SelectItem key={g.id} value={g.id}>
                      <div className="flex items-center gap-2">
                        <Gamepad2 className="h-3.5 w-3.5" />{g.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button
                onClick={add}
                disabled={adding || !pkgName}
                className="w-full md:w-auto h-10 bg-gradient-to-r from-primary to-accent text-primary-foreground"
              >
                {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Plus className="h-4 w-4 mr-2" />Add</>}
              </Button>
            </div>
          </div>
        </div>

        <div className="glass-card-glow p-2 sm:p-4 rounded-xl">
          {loading ? (
            <div className="p-8 text-center"><Loader2 className="h-6 w-6 animate-spin inline" /></div>
          ) : pkgs.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">No approved packages yet</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Package</TableHead>
                    <TableHead>Game</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pkgs.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell className="font-mono text-xs sm:text-sm break-all">{p.package_name}</TableCell>
                      <TableCell className="text-sm">{gameName(p.game_id)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Switch checked={p.is_active} onCheckedChange={() => toggle(p)} />
                          <span className={p.is_active ? "text-success text-xs" : "text-muted-foreground text-xs"}>
                            {p.is_active ? "Active" : "Disabled"}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => remove(p.id)}
                          className="text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
};

export default SdkPackages;
