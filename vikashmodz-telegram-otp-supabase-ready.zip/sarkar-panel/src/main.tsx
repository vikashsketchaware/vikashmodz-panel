import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Auto-refresh page every 20 minutes (background, whether tab is open or not)
setInterval(() => {
  window.location.reload();
}, 20 * 60 * 1000);

createRoot(document.getElementById("root")!).render(<App />);
