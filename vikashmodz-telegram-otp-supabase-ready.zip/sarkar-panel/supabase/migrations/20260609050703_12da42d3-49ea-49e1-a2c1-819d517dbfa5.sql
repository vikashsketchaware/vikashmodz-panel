
-- 1) Revoke admin_action_token column from authenticated/anon (service_role only)
REVOKE SELECT (admin_action_token) ON public.pending_payments FROM authenticated, anon;

-- 2) Re-affirm: revoke sensitive profile columns from authenticated/anon
REVOKE SELECT (otp_bot_token, telegram_chat_id) ON public.profiles FROM authenticated, anon;

-- 3) Songs storage: tighten ownership to file path prefix = uploader uid
DROP POLICY IF EXISTS "Privileged users can upload songs" ON storage.objects;
CREATE POLICY "Privileged users can upload songs to own folder"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'songs'
  AND (auth.uid())::text = (storage.foldername(name))[1]
  AND (
    has_role(auth.uid(), 'owner'::app_role)
    OR has_role(auth.uid(), 'co_owner'::app_role)
    OR has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'reseller'::app_role)
  )
);

-- 4) user_roles: explicit restrictive policy to block self-escalation INSERTs
CREATE POLICY "Only owners can insert roles"
ON public.user_roles
AS RESTRICTIVE
FOR INSERT
TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'owner'::app_role)
  OR has_role(auth.uid(), 'co_owner'::app_role)
);
