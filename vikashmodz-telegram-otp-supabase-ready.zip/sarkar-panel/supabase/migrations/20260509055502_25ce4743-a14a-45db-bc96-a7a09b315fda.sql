ALTER TABLE public.approved_packages
  ADD COLUMN IF NOT EXISTS game_id uuid NULL;

CREATE UNIQUE INDEX IF NOT EXISTS approved_packages_game_pkg_unique
  ON public.approved_packages (COALESCE(game_id::text, ''), package_name);