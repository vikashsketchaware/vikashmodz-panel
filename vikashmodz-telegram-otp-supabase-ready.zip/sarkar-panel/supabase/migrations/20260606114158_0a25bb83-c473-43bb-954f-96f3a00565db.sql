
-- 1. Extend telegram_bots with payment mode + razorpay + stock
ALTER TABLE public.telegram_bots
  ADD COLUMN IF NOT EXISTS payment_mode TEXT NOT NULL DEFAULT 'manual' CHECK (payment_mode IN ('manual','auto')),
  ADD COLUMN IF NOT EXISTS razorpay_key_id TEXT,
  ADD COLUMN IF NOT EXISTS razorpay_key_secret TEXT,
  ADD COLUMN IF NOT EXISTS razorpay_webhook_secret TEXT,
  ADD COLUMN IF NOT EXISTS low_stock_threshold INT NOT NULL DEFAULT 5,
  ADD COLUMN IF NOT EXISTS referral_commission_percent NUMERIC(5,2) NOT NULL DEFAULT 0;

-- 2. Bot discount coupons
CREATE TABLE IF NOT EXISTS public.bot_coupons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bot_id UUID NOT NULL REFERENCES public.telegram_bots(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  discount_type TEXT NOT NULL CHECK (discount_type IN ('percent','flat')),
  discount_value NUMERIC(10,2) NOT NULL,
  max_uses INT,
  times_used INT NOT NULL DEFAULT 0,
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (bot_id, code)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bot_coupons TO authenticated;
GRANT ALL ON public.bot_coupons TO service_role;
ALTER TABLE public.bot_coupons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "bot_coupons_owner_manage" ON public.bot_coupons FOR ALL
  TO authenticated
  USING (created_by = auth.uid() OR has_role(auth.uid(),'owner') OR has_role(auth.uid(),'co_owner'))
  WITH CHECK (created_by = auth.uid() OR has_role(auth.uid(),'owner') OR has_role(auth.uid(),'co_owner'));

-- 3. Bot orders (every purchase logged)
CREATE TABLE IF NOT EXISTS public.bot_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bot_id UUID NOT NULL REFERENCES public.telegram_bots(id) ON DELETE CASCADE,
  telegram_user_id BIGINT NOT NULL,
  telegram_username TEXT,
  game_id UUID,
  duration_hours INT,
  amount NUMERIC(10,2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'INR',
  payment_mode TEXT NOT NULL CHECK (payment_mode IN ('manual','auto')),
  payment_provider TEXT,
  provider_order_id TEXT,
  provider_payment_id TEXT,
  coupon_code TEXT,
  referrer_telegram_id BIGINT,
  commission_amount NUMERIC(10,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','delivered','failed','refunded')),
  delivered_key_id UUID REFERENCES public.license_keys(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.bot_orders TO authenticated;
GRANT ALL ON public.bot_orders TO service_role;
ALTER TABLE public.bot_orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "bot_orders_owner_view" ON public.bot_orders FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM public.telegram_bots b WHERE b.id = bot_orders.bot_id AND b.created_by = auth.uid())
    OR has_role(auth.uid(),'owner') OR has_role(auth.uid(),'co_owner')
  );
CREATE INDEX IF NOT EXISTS idx_bot_orders_bot ON public.bot_orders(bot_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_bot_orders_provider ON public.bot_orders(provider_order_id);

-- 4. Bot referrals (telegram users earning commission)
CREATE TABLE IF NOT EXISTS public.bot_referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bot_id UUID NOT NULL REFERENCES public.telegram_bots(id) ON DELETE CASCADE,
  telegram_user_id BIGINT NOT NULL,
  ref_code TEXT NOT NULL,
  total_earned NUMERIC(10,2) NOT NULL DEFAULT 0,
  total_referred_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (bot_id, telegram_user_id),
  UNIQUE (bot_id, ref_code)
);
GRANT SELECT ON public.bot_referrals TO authenticated;
GRANT ALL ON public.bot_referrals TO service_role;
ALTER TABLE public.bot_referrals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "bot_referrals_owner_view" ON public.bot_referrals FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM public.telegram_bots b WHERE b.id = bot_referrals.bot_id AND b.created_by = auth.uid())
    OR has_role(auth.uid(),'owner') OR has_role(auth.uid(),'co_owner')
  );

-- 5. updated_at trigger for orders
CREATE TRIGGER bot_orders_updated_at
  BEFORE UPDATE ON public.bot_orders
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- 6. Extend telegram_bots_safe view to expose new safe fields (no secrets)
DROP VIEW IF EXISTS public.telegram_bots_safe CASCADE;
CREATE VIEW public.telegram_bots_safe
WITH (security_invoker = true)
AS
SELECT
  id, name, admin_chat_id, upi_id, upi_name, contact_url, webhook_url,
  is_active, created_at, created_by,
  payment_mode,
  CASE WHEN razorpay_key_id IS NOT NULL THEN true ELSE false END AS razorpay_configured,
  low_stock_threshold,
  referral_commission_percent
FROM public.telegram_bots
WHERE created_by = auth.uid()
   OR has_role(auth.uid(),'owner')
   OR has_role(auth.uid(),'co_owner');
GRANT SELECT ON public.telegram_bots_safe TO authenticated;
