DROP VIEW IF EXISTS public.profiles_safe;

ALTER TABLE public.profiles ALTER COLUMN balance TYPE numeric(20,2);
ALTER TABLE public.referral_codes ALTER COLUMN initial_balance TYPE numeric(20,2);

CREATE VIEW public.profiles_safe
WITH (security_invoker = true)
AS
SELECT id,
  username,
  CASE
    WHEN auth.uid() = id OR has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'co_owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) THEN balance
    ELSE NULL::numeric
  END AS balance,
  CASE
    WHEN auth.uid() = id OR has_role(auth.uid(), 'owner'::app_role) OR has_role(auth.uid(), 'co_owner'::app_role) OR has_role(auth.uid(), 'admin'::app_role) THEN account_expires_at
    ELSE NULL::timestamp with time zone
  END AS account_expires_at,
  mask_telegram_id(telegram_chat_id, auth.uid(), id) AS telegram_chat_id,
  status,
  is_hidden,
  panel_name,
  invited_by,
  referral_applied,
  requires_otp,
  two_factor_enabled,
  last_login,
  created_at,
  updated_at
FROM public.profiles;

GRANT SELECT ON public.profiles_safe TO authenticated;

DELETE FROM public.ip_blacklist WHERE reason ILIKE '%register%' OR reason ILIKE '%referral%';