
-- 1. Revoke profile sensitive cols from client
REVOKE SELECT (otp_bot_token, telegram_chat_id) ON public.profiles FROM authenticated, anon;

-- 2. Deny client SELECT on owner_otp_codes (server-side only)
DROP POLICY IF EXISTS "Users can view own OTP codes" ON public.owner_otp_codes;
CREATE POLICY "Deny client SELECT on owner_otp_codes" ON public.owner_otp_codes FOR SELECT TO authenticated USING (false);

-- 3. Deny client SELECT on two_factor_codes
DROP POLICY IF EXISTS "Users can view own 2FA codes" ON public.two_factor_codes;
CREATE POLICY "Deny client SELECT on two_factor_codes" ON public.two_factor_codes FOR SELECT TO authenticated USING (false);

-- 4. Restrict songs bucket upload to privileged roles
DROP POLICY IF EXISTS "Authenticated users can upload songs" ON storage.objects;
CREATE POLICY "Privileged users can upload songs" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'songs' AND (
      public.has_role(auth.uid(), 'owner') OR
      public.has_role(auth.uid(), 'co_owner') OR
      public.has_role(auth.uid(), 'admin') OR
      public.has_role(auth.uid(), 'reseller')
    )
  );
