
-- 1) Remove broad profile broadcasts from realtime publication
ALTER PUBLICATION supabase_realtime DROP TABLE public.profiles;

-- 2) Explicit deny on price_settings for non-privileged authenticated users
DROP POLICY IF EXISTS "Deny non-admin authenticated read on price_settings" ON public.price_settings;
CREATE POLICY "Deny non-admin authenticated read on price_settings"
ON public.price_settings
AS RESTRICTIVE
FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'owner')
  OR public.has_role(auth.uid(), 'co_owner')
  OR public.has_role(auth.uid(), 'admin')
);

-- 3) Explicit deny on pending_payments for non-privileged authenticated users
DROP POLICY IF EXISTS "Deny non-admin authenticated read on pending_payments" ON public.pending_payments;
CREATE POLICY "Deny non-admin authenticated read on pending_payments"
ON public.pending_payments
AS RESTRICTIVE
FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'owner')
  OR public.has_role(auth.uid(), 'co_owner')
  OR public.has_role(auth.uid(), 'admin')
);
