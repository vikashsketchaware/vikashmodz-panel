
REVOKE SELECT (bot_token, razorpay_key_secret, razorpay_webhook_secret) ON public.telegram_bots FROM authenticated, anon;
