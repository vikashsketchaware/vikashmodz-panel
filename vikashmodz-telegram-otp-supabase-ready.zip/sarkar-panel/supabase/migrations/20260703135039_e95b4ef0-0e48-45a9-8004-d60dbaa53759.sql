
DROP POLICY IF EXISTS "Users can update their own songs" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their own songs" ON storage.objects;

CREATE POLICY "Privileged users can update own song files"
ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'songs'
  AND (storage.foldername(name))[1] = auth.uid()::text
  AND (
    public.has_role(auth.uid(), 'owner')
    OR public.has_role(auth.uid(), 'co_owner')
    OR public.has_role(auth.uid(), 'admin')
    OR public.has_role(auth.uid(), 'reseller')
  )
)
WITH CHECK (
  bucket_id = 'songs'
  AND (storage.foldername(name))[1] = auth.uid()::text
  AND (
    public.has_role(auth.uid(), 'owner')
    OR public.has_role(auth.uid(), 'co_owner')
    OR public.has_role(auth.uid(), 'admin')
    OR public.has_role(auth.uid(), 'reseller')
  )
);

CREATE POLICY "Privileged users can delete own song files"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'songs'
  AND (storage.foldername(name))[1] = auth.uid()::text
  AND (
    public.has_role(auth.uid(), 'owner')
    OR public.has_role(auth.uid(), 'co_owner')
    OR public.has_role(auth.uid(), 'admin')
    OR public.has_role(auth.uid(), 'reseller')
  )
);
