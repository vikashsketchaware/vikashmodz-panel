
CREATE TABLE IF NOT EXISTS public.api_request_nonces (
  nonce text NOT NULL PRIMARY KEY,
  endpoint text NOT NULL,
  ip_address inet,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_nonces_created ON public.api_request_nonces(created_at);

ALTER TABLE public.api_request_nonces ENABLE ROW LEVEL SECURITY;
CREATE POLICY "deny anon nonces" ON public.api_request_nonces FOR ALL TO anon USING (false) WITH CHECK (false);
CREATE POLICY "owners view nonces" ON public.api_request_nonces FOR SELECT TO authenticated
  USING (has_role(auth.uid(),'owner'::app_role) OR has_role(auth.uid(),'admin'::app_role));

CREATE TABLE IF NOT EXISTS public.canary_hits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_address inet NOT NULL,
  path text NOT NULL,
  user_agent text,
  signal text,
  details jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_canary_ip ON public.canary_hits(ip_address);
CREATE INDEX IF NOT EXISTS idx_canary_created ON public.canary_hits(created_at DESC);

ALTER TABLE public.canary_hits ENABLE ROW LEVEL SECURITY;
CREATE POLICY "deny anon canary" ON public.canary_hits FOR ALL TO anon USING (false) WITH CHECK (false);
CREATE POLICY "owners view canary" ON public.canary_hits FOR SELECT TO authenticated
  USING (has_role(auth.uid(),'owner'::app_role) OR has_role(auth.uid(),'admin'::app_role));

CREATE OR REPLACE FUNCTION public.cleanup_old_nonces()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  DELETE FROM public.api_request_nonces WHERE created_at < now() - interval '15 minutes';
  DELETE FROM public.canary_hits WHERE created_at < now() - interval '30 days';
END;
$$;
