import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, password, bootstrap_secret } = await req.json();

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    // SECURITY: prevent privilege escalation.
    // 1) If an owner already exists, the function is locked. Use admin-actions/change_role instead.
    // 2) For first-time bootstrap, require OWNER_BOOTSTRAP_SECRET env match.
    const { data: existingOwners } = await supabaseAdmin
      .from("user_roles")
      .select("user_id")
      .eq("role", "owner")
      .limit(1);
    if (existingOwners && existingOwners.length > 0) {
      return new Response(
        JSON.stringify({ error: "Owner already exists. This bootstrap endpoint is disabled." }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    const required = Deno.env.get("OWNER_BOOTSTRAP_SECRET");
    if (!required || bootstrap_secret !== required) {
      return new Response(
        JSON.stringify({ error: "Forbidden" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create the user
    const { data: userData, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });

    if (createError) {
      throw createError;
    }

    const userId = userData.user.id;

    // Update user_roles to owner (the trigger creates 'admin' by default)
    await supabaseAdmin
      .from("user_roles")
      .update({ role: "owner" })
      .eq("user_id", userId);

    // Update profile status to active
    await supabaseAdmin
      .from("profiles")
      .update({ status: "active" })
      .eq("id", userId);

    return new Response(
      JSON.stringify({ success: true, user_id: userId }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("Error creating owner:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
