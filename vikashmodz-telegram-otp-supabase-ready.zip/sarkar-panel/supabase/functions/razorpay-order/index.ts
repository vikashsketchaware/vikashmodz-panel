// Server-side Razorpay Payment Link creator (per-bot keys, no client-side secret exposure)
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405, headers: corsHeaders });

  try {
    const body = await req.json();
    const { bot_id, telegram_user_id, telegram_username, duration_hours, coupon_code } = body || {};
    let { game_id } = body || {};

    if (!bot_id || !telegram_user_id || !duration_hours) {
      return new Response(JSON.stringify({ error: "missing fields" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (typeof duration_hours !== "number" || duration_hours <= 0 || duration_hours > 24 * 365) {
      return new Response(JSON.stringify({ error: "invalid duration" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabase = createClient(SUPABASE_URL, SERVICE_KEY);
    const { data: bot, error: botErr } = await supabase
      .from("telegram_bots")
      .select("id, razorpay_key_id, razorpay_key_secret, payment_mode, display_name, upi_name, is_active")
      .eq("id", bot_id)
      .maybeSingle();

    if (botErr || !bot || !bot.is_active) {
      return new Response(JSON.stringify({ error: "bot unavailable" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (bot.payment_mode !== "auto" || !bot.razorpay_key_id || !bot.razorpay_key_secret) {
      return new Response(JSON.stringify({ error: "auto payment not configured" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Fallback: pick first active game if caller didn't specify
    if (!game_id) {
      const { data: g } = await supabase.from("games").select("id").eq("status", "active").limit(1).maybeSingle();
      game_id = g?.id || null;
    }
    if (!game_id) {
      return new Response(JSON.stringify({ error: "no active game" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // SERVER-SIDE PRICE LOOKUP — never trust client amount
    // Prefer bot-specific price, fall back to global price for the game/duration
    const { data: botPrice } = await supabase
      .from("price_settings")
      .select("price")
      .eq("bot_id", bot_id)
      .eq("game_id", game_id)
      .eq("duration_hours", duration_hours)
      .maybeSingle();
    let baseAmount: number | null = botPrice?.price ? Number(botPrice.price) : null;
    if (baseAmount === null) {
      const { data: globalPrice } = await supabase
        .from("price_settings")
        .select("price")
        .is("bot_id", null)
        .eq("game_id", game_id)
        .eq("duration_hours", duration_hours)
        .maybeSingle();
      baseAmount = globalPrice?.price ? Number(globalPrice.price) : null;
    }
    if (!baseAmount || baseAmount <= 0) {
      return new Response(JSON.stringify({ error: "price not configured" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    let finalAmount = baseAmount;
    let appliedCoupon: string | null = null;
    if (coupon_code) {
      const { data: coupon } = await supabase
        .from("bot_coupons")
        .select("*")
        .eq("bot_id", bot_id)
        .eq("code", coupon_code)
        .eq("is_active", true)
        .maybeSingle();
      if (coupon && (!coupon.max_uses || coupon.times_used < coupon.max_uses)
        && (!coupon.expires_at || new Date(coupon.expires_at) > new Date())) {
        if (coupon.discount_type === "percent") {
          finalAmount = Math.max(1, finalAmount * (1 - Number(coupon.discount_value) / 100));
        } else {
          finalAmount = Math.max(1, finalAmount - Number(coupon.discount_value));
        }
        finalAmount = Math.round(finalAmount * 100) / 100;
        appliedCoupon = coupon_code;
      }
    }

    // Create pending order BEFORE calling Razorpay so we can correlate
    const { data: order, error: orderErr } = await supabase
      .from("bot_orders")
      .insert({
        bot_id,
        telegram_user_id,
        telegram_username: telegram_username || null,
        game_id: game_id || null,
        duration_hours: duration_hours || null,
        amount: finalAmount,
        currency: "INR",
        payment_mode: "auto",
        payment_provider: "razorpay",
        coupon_code: appliedCoupon,
        status: "pending",
      })
      .select()
      .single();

    if (orderErr || !order) {
      return new Response(JSON.stringify({ error: "order create failed" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Create Razorpay Payment Link
    const auth = btoa(`${bot.razorpay_key_id}:${bot.razorpay_key_secret}`);
    const linkRes = await fetch("https://api.razorpay.com/v1/payment_links", {
      method: "POST",
      headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        amount: Math.round(finalAmount * 100), // paise
        currency: "INR",
        accept_partial: false,
        description: `Key purchase - ${duration_hours || 0}h`,
        reference_id: order.id,
        notes: { order_id: order.id, bot_id, telegram_user_id: String(telegram_user_id) },
        notify: { sms: false, email: false },
        reminder_enable: false,
      }),
    });

    const linkData = await linkRes.json();
    if (!linkRes.ok || !linkData?.short_url) {
      await supabase.from("bot_orders").update({ status: "failed" }).eq("id", order.id);
      return new Response(JSON.stringify({ error: "razorpay error", detail: linkData?.error?.description || "unknown" }), { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    await supabase.from("bot_orders").update({
      provider_order_id: linkData.id,
    }).eq("id", order.id);

    return new Response(JSON.stringify({
      ok: true,
      order_id: order.id,
      payment_url: linkData.short_url,
      amount: finalAmount,
      coupon_applied: appliedCoupon,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: "internal", detail: String(e) }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});