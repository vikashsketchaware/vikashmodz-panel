import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2";

// ============================================
// SECURITY CONFIGURATION
// ============================================
const ALLOWED_ORIGINS = [
  "https://kuro-panel.lovable.app",
  "https://dynamic-kuro-panel.lovable.app",
  "https://id-preview--a11ea329-69d2-485f-b0db-62a1a5e93a38.lovable.app"
];

const RATE_LIMIT_WINDOW_MS = 60000; // default: 1 minute
const RATE_LIMIT_MAX_REQUESTS = 100; // default: 100 requests per minute per IP

// Per-endpoint overrides (anti brute-force / spam on connect endpoints)
// 100 requests per 2 minutes per IP for connect + sdk-connect, tracked separately.
const ENDPOINT_RATE_LIMITS: Record<string, { windowMs: number; max: number }> = {
  "connect":     { windowMs: 120_000, max: 100 },
  "sdk-connect": { windowMs: 120_000, max: 100 },
  "sdk-verify":  { windowMs: 120_000, max: 100 },
};
const MAX_FAILED_ATTEMPTS = 100; // Auto-block after 100 failed attempts (relaxed)
const BLOCK_DURATION_MS = 24 * 60 * 60 * 1000; // 24 hour ban
const MAX_BODY_SIZE = 8192; // 8KB max request body
const MAX_FIELD_LENGTH = 512; // Max length for any single field

// Anti-canary configuration
const VALID_ENDPOINTS = new Set(["connect", "connect-enc", "activate", "verify", "heartbeat", "sdk-verify"]);

// ============================================
// AES-128-CBC response encryption (matches C++ loader decode_and_decrypt)
// Client does: base64_decode -> AES-128-CBC decrypt (PKCS7) -> JSON.parse
// So server does: JSON.stringify -> AES-128-CBC encrypt (PKCS7) -> base64
// ============================================
const ENC_KEY_BYTES = new TextEncoder().encode("b591nKHFOnXpwu0W"); // 16 bytes
const ENC_IV_BYTES = new TextEncoder().encode("zcN3ZOg4uhjw6H9S"); // 16 bytes

function b64encode(bytes: Uint8Array): string {
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

async function encryptResponseBody(jsonText: string): Promise<string> {
  const plainBytes = new TextEncoder().encode(jsonText);
  const cryptoKey = await crypto.subtle.importKey(
    "raw", ENC_KEY_BYTES, { name: "AES-CBC" }, false, ["encrypt"]
  );
  const cipherBuf = await crypto.subtle.encrypt(
    { name: "AES-CBC", iv: ENC_IV_BYTES },
    cryptoKey,
    plainBytes
  );
  return b64encode(new Uint8Array(cipherBuf));
}

async function toEncryptedResponse(resp: Response, corsHeaders: Record<string, string>): Promise<Response> {
  const text = await resp.text();
  const encoded = await encryptResponseBody(text);
  return new Response(encoded, {
    status: resp.status,
    headers: {
      ...corsHeaders,
      ...SECURITY_RESPONSE_HEADERS,
      "Content-Type": "text/plain; charset=utf-8",
    },
  });
}
// Hitting any of these = instant 24h ban (honeypot/canary trap)
const CANARY_PATH_PATTERNS = [
  /\.(env|git|aws|ssh|sql|bak|backup|old|swp)$/i,
  /\/(admin|administrator|wp-admin|phpmyadmin|adminer)/i,
  /\/(debug|console|shell|exec|eval|cmd|test|api|v1|v2|graphql)$/i,
  /\/(config|secret|password|credentials|token)/i,
  /\/(\.well-known|robots\.txt|sitemap)/i,
  /(union\s+select|drop\s+table|<script|javascript:)/i,
];
// Anti-debug signal fields the SDK reports — any truthy = reject + ban
const DEBUG_SIGNAL_FIELDS = ["frida", "xposed", "debugger", "magisk", "hook", "emulator", "tampered"];
// SDK request freshness window
const SDK_TS_WINDOW_MS = 120_000; // ±2 minutes

// Security headers (Cloudflare Transform Rules equivalent)
const SECURITY_RESPONSE_HEADERS: Record<string, string> = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "X-XSS-Protection": "1; mode=block",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy": "geolocation=(), camera=(), microphone=()",
};

// Blocked User-Agents (WAF rule)
const BLOCKED_USER_AGENTS = [
  "python-requests", "curl", "wget", "httpie", "postman",
  "insomnia", "scrapy", "httpclient", "go-http-client",
  "node-fetch", "undici", "got/", "superagent",
  "libwww-perl", "lwp-", "winhttp", "powershell",
];

// Get CORS headers with origin validation
function getCorsHeaders(req: Request): Record<string, string> {
  const origin = req.headers.get("origin");
  const corsOrigin = !origin || ALLOWED_ORIGINS.includes(origin) 
    ? (origin || ALLOWED_ORIGINS[0]) 
    : ALLOWED_ORIGINS[0];

  return {
    "Access-Control-Allow-Origin": corsOrigin,
    "Access-Control-Allow-Headers": "content-type, x-client-info",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    ...SECURITY_RESPONSE_HEADERS,
  };
}

function jsonResponse(data: Record<string, unknown>, status = 200, corsHeaders: Record<string, string>) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// ============================================
// SECURITY HELPERS
// ============================================

// Check if IP is blacklisted
async function isIpBlacklisted(supabase: SupabaseClient, ip: string): Promise<boolean> {
  const { data } = await supabase
    .from("ip_blacklist")
    .select("id")
    .eq("ip_address", ip)
    .or("expires_at.is.null,expires_at.gt.now()")
    .maybeSingle();
  
  return !!data;
}

// Check rate limit (per IP + endpoint bucket)
async function checkRateLimit(supabase: SupabaseClient, ip: string, endpoint: string): Promise<boolean> {
  const cfg = ENDPOINT_RATE_LIMITS[endpoint] ?? { windowMs: RATE_LIMIT_WINDOW_MS, max: RATE_LIMIT_MAX_REQUESTS };
  const windowStart = new Date(Date.now() - cfg.windowMs).toISOString();

  const { count } = await supabase
    .from("api_rate_limits")
    .select("*", { count: "exact", head: true })
    .eq("ip_address", ip)
    .eq("endpoint", endpoint)
    .gte("window_start", windowStart);

  if ((count || 0) >= cfg.max) {
    // Track as failed attempt so repeat offenders get auto-blacklisted
    await trackFailedAttempt(supabase, ip, `rate_limit:${endpoint}`).catch(() => {});
    return false; // Rate limited
  }

  // Record this request
  await supabase.from("api_rate_limits").insert({
    ip_address: ip,
    endpoint: endpoint,
    window_start: new Date().toISOString()
  });

  return true; // OK
}

// Track failed attempt and auto-block if needed
async function trackFailedAttempt(supabase: SupabaseClient, ip: string, reason: string): Promise<void> {
  // Upsert failed attempts counter
  const { data: existing } = await supabase
    .from("failed_auth_attempts")
    .select("id, attempt_count")
    .eq("ip_address", ip)
    .maybeSingle();
  
  if (existing) {
    const newCount = (existing.attempt_count || 0) + 1;
    await supabase
      .from("failed_auth_attempts")
      .update({ 
        attempt_count: newCount,
        last_attempt_at: new Date().toISOString()
      })
      .eq("id", existing.id);
    
    // Auto-block if too many failures
    if (newCount >= MAX_FAILED_ATTEMPTS) {
      await supabase.from("ip_blacklist").upsert({
        ip_address: ip,
        reason: `Auto-blocked: ${MAX_FAILED_ATTEMPTS} failed auth attempts. Last reason: ${reason}`,
        expires_at: new Date(Date.now() + BLOCK_DURATION_MS).toISOString()
      }, { onConflict: "ip_address" });
    }
  } else {
    await supabase.from("failed_auth_attempts").insert({
      ip_address: ip,
      attempt_count: 1
    });
  }
}

// Log API request for audit
async function logApiRequest(
  supabase: SupabaseClient, 
  ip: string, 
  endpoint: string, 
  userKey: string | null,
  success: boolean,
  failureReason: string | null,
  requestData: Record<string, unknown> | null
): Promise<void> {
  // Sanitize request data - remove sensitive fields
  const sanitizedData = requestData ? {
    ...requestData,
    serial: requestData.serial ? "***REDACTED***" : undefined
  } : null;

  await supabase.from("api_audit_logs").insert({
    ip_address: ip,
    endpoint: endpoint,
    user_key: userKey,
    success: success,
    failure_reason: failureReason,
    request_data: sanitizedData
  });
}

// MD5 hash function to match C++ client's token validation
// Pure JS implementation since Deno crypto.subtle doesn't support MD5
function md5Hash(message: string): string {
  const md5 = (str: string): string => {
    function rotateLeft(x: number, n: number): number {
      return (x << n) | (x >>> (32 - n));
    }

    function addUnsigned(x: number, y: number): number {
      const x8 = x & 0x80000000;
      const y8 = y & 0x80000000;
      const x4 = x & 0x40000000;
      const y4 = y & 0x40000000;
      const result = (x & 0x3fffffff) + (y & 0x3fffffff);
      if (x4 & y4) return result ^ 0x80000000 ^ x8 ^ y8;
      if (x4 | y4) {
        if (result & 0x40000000) return result ^ 0xc0000000 ^ x8 ^ y8;
        return result ^ 0x40000000 ^ x8 ^ y8;
      }
      return result ^ x8 ^ y8;
    }

    function f(x: number, y: number, z: number): number { return (x & y) | (~x & z); }
    function g(x: number, y: number, z: number): number { return (x & z) | (y & ~z); }
    function h(x: number, y: number, z: number): number { return x ^ y ^ z; }
    function i(x: number, y: number, z: number): number { return y ^ (x | ~z); }

    function ff(a: number, b: number, c: number, d: number, x: number, s: number, ac: number): number {
      a = addUnsigned(a, addUnsigned(addUnsigned(f(b, c, d), x), ac));
      return addUnsigned(rotateLeft(a, s), b);
    }
    function gg(a: number, b: number, c: number, d: number, x: number, s: number, ac: number): number {
      a = addUnsigned(a, addUnsigned(addUnsigned(g(b, c, d), x), ac));
      return addUnsigned(rotateLeft(a, s), b);
    }
    function hh(a: number, b: number, c: number, d: number, x: number, s: number, ac: number): number {
      a = addUnsigned(a, addUnsigned(addUnsigned(h(b, c, d), x), ac));
      return addUnsigned(rotateLeft(a, s), b);
    }
    function ii(a: number, b: number, c: number, d: number, x: number, s: number, ac: number): number {
      a = addUnsigned(a, addUnsigned(addUnsigned(i(b, c, d), x), ac));
      return addUnsigned(rotateLeft(a, s), b);
    }

    function convertToWordArray(str: string): number[] {
      const bytes = new TextEncoder().encode(str);
      const numWords = (((bytes.length + 8) >>> 6) + 1) << 4;
      const words: number[] = new Array(numWords).fill(0);
      for (let i = 0; i < bytes.length; i++) {
        words[i >>> 2] |= bytes[i] << ((i % 4) * 8);
      }
      words[bytes.length >>> 2] |= 0x80 << ((bytes.length % 4) * 8);
      words[numWords - 2] = bytes.length * 8;
      return words;
    }

    function wordToHex(value: number): string {
      let hex = "";
      for (let i = 0; i < 4; i++) {
        const byte = (value >>> (i * 8)) & 0xff;
        hex += byte.toString(16).padStart(2, "0");
      }
      return hex;
    }

    const x = convertToWordArray(str);
    let a = 0x67452301, b = 0xefcdab89, c = 0x98badcfe, d = 0x10325476;

    const S11 = 7, S12 = 12, S13 = 17, S14 = 22;
    const S21 = 5, S22 = 9, S23 = 14, S24 = 20;
    const S31 = 4, S32 = 11, S33 = 16, S34 = 23;
    const S41 = 6, S42 = 10, S43 = 15, S44 = 21;

    for (let k = 0; k < x.length; k += 16) {
      const AA = a, BB = b, CC = c, DD = d;

      a = ff(a, b, c, d, x[k + 0], S11, 0xd76aa478);
      d = ff(d, a, b, c, x[k + 1], S12, 0xe8c7b756);
      c = ff(c, d, a, b, x[k + 2], S13, 0x242070db);
      b = ff(b, c, d, a, x[k + 3], S14, 0xc1bdceee);
      a = ff(a, b, c, d, x[k + 4], S11, 0xf57c0faf);
      d = ff(d, a, b, c, x[k + 5], S12, 0x4787c62a);
      c = ff(c, d, a, b, x[k + 6], S13, 0xa8304613);
      b = ff(b, c, d, a, x[k + 7], S14, 0xfd469501);
      a = ff(a, b, c, d, x[k + 8], S11, 0x698098d8);
      d = ff(d, a, b, c, x[k + 9], S12, 0x8b44f7af);
      c = ff(c, d, a, b, x[k + 10], S13, 0xffff5bb1);
      b = ff(b, c, d, a, x[k + 11], S14, 0x895cd7be);
      a = ff(a, b, c, d, x[k + 12], S11, 0x6b901122);
      d = ff(d, a, b, c, x[k + 13], S12, 0xfd987193);
      c = ff(c, d, a, b, x[k + 14], S13, 0xa679438e);
      b = ff(b, c, d, a, x[k + 15], S14, 0x49b40821);

      a = gg(a, b, c, d, x[k + 1], S21, 0xf61e2562);
      d = gg(d, a, b, c, x[k + 6], S22, 0xc040b340);
      c = gg(c, d, a, b, x[k + 11], S23, 0x265e5a51);
      b = gg(b, c, d, a, x[k + 0], S24, 0xe9b6c7aa);
      a = gg(a, b, c, d, x[k + 5], S21, 0xd62f105d);
      d = gg(d, a, b, c, x[k + 10], S22, 0x02441453);
      c = gg(c, d, a, b, x[k + 15], S23, 0xd8a1e681);
      b = gg(b, c, d, a, x[k + 4], S24, 0xe7d3fbc8);
      a = gg(a, b, c, d, x[k + 9], S21, 0x21e1cde6);
      d = gg(d, a, b, c, x[k + 14], S22, 0xc33707d6);
      c = gg(c, d, a, b, x[k + 3], S23, 0xf4d50d87);
      b = gg(b, c, d, a, x[k + 8], S24, 0x455a14ed);
      a = gg(a, b, c, d, x[k + 13], S21, 0xa9e3e905);
      d = gg(d, a, b, c, x[k + 2], S22, 0xfcefa3f8);
      c = gg(c, d, a, b, x[k + 7], S23, 0x676f02d9);
      b = gg(b, c, d, a, x[k + 12], S24, 0x8d2a4c8a);

      a = hh(a, b, c, d, x[k + 5], S31, 0xfffa3942);
      d = hh(d, a, b, c, x[k + 8], S32, 0x8771f681);
      c = hh(c, d, a, b, x[k + 11], S33, 0x6d9d6122);
      b = hh(b, c, d, a, x[k + 14], S34, 0xfde5380c);
      a = hh(a, b, c, d, x[k + 1], S31, 0xa4beea44);
      d = hh(d, a, b, c, x[k + 4], S32, 0x4bdecfa9);
      c = hh(c, d, a, b, x[k + 7], S33, 0xf6bb4b60);
      b = hh(b, c, d, a, x[k + 10], S34, 0xbebfbc70);
      a = hh(a, b, c, d, x[k + 13], S31, 0x289b7ec6);
      d = hh(d, a, b, c, x[k + 0], S32, 0xeaa127fa);
      c = hh(c, d, a, b, x[k + 3], S33, 0xd4ef3085);
      b = hh(b, c, d, a, x[k + 6], S34, 0x04881d05);
      a = hh(a, b, c, d, x[k + 9], S31, 0xd9d4d039);
      d = hh(d, a, b, c, x[k + 12], S32, 0xe6db99e5);
      c = hh(c, d, a, b, x[k + 15], S33, 0x1fa27cf8);
      b = hh(b, c, d, a, x[k + 2], S34, 0xc4ac5665);

      a = ii(a, b, c, d, x[k + 0], S41, 0xf4292244);
      d = ii(d, a, b, c, x[k + 7], S42, 0x432aff97);
      c = ii(c, d, a, b, x[k + 14], S43, 0xab9423a7);
      b = ii(b, c, d, a, x[k + 5], S44, 0xfc93a039);
      a = ii(a, b, c, d, x[k + 12], S41, 0x655b59c3);
      d = ii(d, a, b, c, x[k + 3], S42, 0x8f0ccc92);
      c = ii(c, d, a, b, x[k + 10], S43, 0xffeff47d);
      b = ii(b, c, d, a, x[k + 1], S44, 0x85845dd1);
      a = ii(a, b, c, d, x[k + 8], S41, 0x6fa87e4f);
      d = ii(d, a, b, c, x[k + 15], S42, 0xfe2ce6e0);
      c = ii(c, d, a, b, x[k + 6], S43, 0xa3014314);
      b = ii(b, c, d, a, x[k + 13], S44, 0x4e0811a1);
      a = ii(a, b, c, d, x[k + 4], S41, 0xf7537e82);
      d = ii(d, a, b, c, x[k + 11], S42, 0xbd3af235);
      c = ii(c, d, a, b, x[k + 2], S43, 0x2ad7d2bb);
      b = ii(b, c, d, a, x[k + 9], S44, 0xeb86d391);

      a = addUnsigned(a, AA);
      b = addUnsigned(b, BB);
      c = addUnsigned(c, CC);
      d = addUnsigned(d, DD);
    }

    return wordToHex(a) + wordToHex(b) + wordToHex(c) + wordToHex(d);
  };

  return md5(message);
}

// Parse body from JSON or form-urlencoded format (from Request)
// ============================================
// ANTI-CANARY HELPERS
// ============================================

// Log canary hit + auto-ban IP for 24h
async function tripCanary(
  supabase: SupabaseClient,
  ip: string,
  path: string,
  signal: string,
  userAgent: string,
  details: Record<string, unknown> = {}
): Promise<void> {
  try {
    await supabase.from("canary_hits").insert({
      ip_address: ip,
      path,
      signal,
      user_agent: userAgent,
      details,
    });
    await supabase.from("ip_blacklist").upsert({
      ip_address: ip,
      reason: `CANARY_TRIPPED: ${signal} on ${path}`,
      expires_at: new Date(Date.now() + BLOCK_DURATION_MS).toISOString(),
    }, { onConflict: "ip_address" });
  } catch { /* swallow */ }
}

// HMAC-SHA256 hex
async function hmacSha256Hex(secret: string, message: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message));
  return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, "0")).join("");
}

// Constant-time string compare
function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

// Verify SDK request signature: x-sdk-ts (epoch sec), x-sdk-nonce, x-sdk-sig = HMAC(SECRET, ts+nonce+user_key+package_name)
async function verifySdkSignature(
  supabase: SupabaseClient,
  req: Request,
  body: { user_key?: string; package_name?: string },
  secret: string
): Promise<{ ok: true } | { ok: false; reason: string }> {
  const ts = req.headers.get("x-sdk-ts");
  const nonce = req.headers.get("x-sdk-nonce");
  const sig = req.headers.get("x-sdk-sig");
  if (!ts || !nonce || !sig) return { ok: false, reason: "MISSING_SIG" };
  if (nonce.length < 16 || nonce.length > 64) return { ok: false, reason: "BAD_NONCE" };

  const tsNum = parseInt(ts, 10);
  if (!Number.isFinite(tsNum)) return { ok: false, reason: "BAD_TS" };
  const drift = Math.abs(Date.now() - tsNum * 1000);
  if (drift > SDK_TS_WINDOW_MS) return { ok: false, reason: "STALE_TS" };

  const expected = await hmacSha256Hex(secret, `${ts}.${nonce}.${body.user_key ?? ""}.${body.package_name ?? ""}`);
  if (!safeEqual(expected, sig.toLowerCase())) return { ok: false, reason: "BAD_SIG" };

  // Replay protection — nonce must be unique
  const { error: nonceErr } = await supabase
    .from("api_request_nonces")
    .insert({ nonce, endpoint: "sdk-connect" });
  if (nonceErr) return { ok: false, reason: "REPLAY" };

  return { ok: true };
}

// Detect anti-debug signals in body — any truthy = trap
function detectDebugSignal(body: Record<string, unknown>): string | null {
  const signals = (body.signals && typeof body.signals === "object") ? body.signals as Record<string, unknown> : body;
  for (const f of DEBUG_SIGNAL_FIELDS) {
    const v = signals[f];
    if (v === true || v === "true" || v === "1" || v === 1) return f;
  }
  return null;
}

async function parseBody(req: Request): Promise<Record<string, string>> {
  const contentType = req.headers.get("content-type") || "";
  
  if (contentType.includes("application/json")) {
    return await req.json();
  } 
  
  if (contentType.includes("application/x-www-form-urlencoded")) {
    const text = await req.text();
    const params = new URLSearchParams(text);
    const result: Record<string, string> = {};
    for (const [key, value] of params) {
      result[key] = value;
    }
    return result;
  }
  
  // Default: try JSON first, then form-encoded
  const text = await req.text();
  try {
    return JSON.parse(text);
  } catch {
    const params = new URLSearchParams(text);
    const result: Record<string, string> = {};
    for (const [key, value] of params) {
      result[key] = value;
    }
    return result;
  }
}


// Format duration to human readable string
function formatDuration(hours: number): string {
  if (hours < 24) {
    return hours === 1 ? "1 Hour" : `${hours} Hours`;
  }
  const days = Math.floor(hours / 24);
  if (days < 30) {
    return days === 1 ? "1 Day" : `${days} Days`;
  }
  const months = Math.floor(days / 30);
  if (months < 12) {
    return months === 1 ? "1 Month" : `${months} Months`;
  }
  const years = Math.floor(months / 12);
  return years === 1 ? "1 Year" : `${years} Years`;
}

interface LicenseKey {
  id: string;
  key_code: string;
  game_id: string;
  duration_hours: number;
  max_devices: number;
  status: string;
  activated_at: string | null;
  expires_at: string | null;
  games?: { id: string; name: string; mod_name: string | null } | null;
}

interface KeyActivation {
  id: string;
  key_id: string;
  device_fingerprint: string;
  device_info: Record<string, unknown> | null;
  ip_address: string | null;
  last_seen: string;
}

async function handleActivate(
  supabase: SupabaseClient,
  body: { key_code: string; device_fingerprint: string; device_info?: Record<string, unknown> },
  clientIp: string,
  corsHeaders: Record<string, string>
) {
  const { key_code, device_fingerprint, device_info } = body;

  if (!key_code || !device_fingerprint) {
    await logApiRequest(supabase, clientIp, "activate", key_code, false, "MISSING_FIELDS", null);
    return jsonResponse({ error: "Invalid request" }, 400, corsHeaders);
  }

  // 1. Find the key
  const { data: key, error } = await supabase
    .from("license_keys")
    .select("*, games(id, name, mod_name)")
    .eq("key_code", key_code)
    .single<LicenseKey>();

  if (error || !key) {
    await trackFailedAttempt(supabase, clientIp, "INVALID_KEY");
    await logApiRequest(supabase, clientIp, "activate", key_code, false, "INVALID_KEY", null);
    return jsonResponse({ error: "Invalid request" }, 404, corsHeaders);
  }

  // OBFUSCATED: All status errors return generic message
  if (key.status === "revoked" || key.status === "paused") {
    await logApiRequest(supabase, clientIp, "activate", key_code, false, `KEY_${key.status.toUpperCase()}`, null);
    return jsonResponse({ error: "Unable to process request" }, 403, corsHeaders);
  }

  // 2. Check if already expired
  if (key.expires_at && new Date(key.expires_at) < new Date()) {
    await supabase.from("key_activations").delete().eq("key_id", key.id);
    await supabase.from("license_keys").update({ status: "expired" }).eq("id", key.id);
    await logApiRequest(supabase, clientIp, "activate", key_code, false, "KEY_EXPIRED", null);
    return jsonResponse({ error: "Unable to process request" }, 403, corsHeaders);
  }

  // 3. Count current activations
  const { count } = await supabase
    .from("key_activations")
    .select("*", { count: "exact", head: true })
    .eq("key_id", key.id);

  // 4. Check if this device is already activated
  const { data: existingActivation } = await supabase
    .from("key_activations")
    .select("*")
    .eq("key_id", key.id)
    .eq("device_fingerprint", device_fingerprint)
    .maybeSingle<KeyActivation>();

  if (existingActivation) {
    await supabase
      .from("key_activations")
      .update({ 
        last_seen: new Date().toISOString(),
        ip_address: clientIp,
        device_info: device_info || existingActivation.device_info
      })
      .eq("id", existingActivation.id);
  } else {
    if ((count || 0) >= key.max_devices) {
      await logApiRequest(supabase, clientIp, "activate", key_code, false, "MAX_DEVICES", null);
      return jsonResponse({ error: "Unable to process request" }, 403, corsHeaders);
    }

    const { error: insertError } = await supabase.from("key_activations").insert({
      key_id: key.id,
      device_fingerprint,
      device_info: device_info || {},
      ip_address: clientIp,
    });

    if (insertError) {
      console.error("Activation error");
      await logApiRequest(supabase, clientIp, "activate", key_code, false, "INSERT_ERROR", null);
      return jsonResponse({ error: "Unable to process request" }, 500, corsHeaders);
    }
  }

  // 5. Set activation time if first activation
  let expiresAt = key.expires_at;
  if (!key.activated_at) {
    expiresAt = new Date(Date.now() + key.duration_hours * 60 * 60 * 1000).toISOString();
    await supabase
      .from("license_keys")
      .update({ 
        activated_at: new Date().toISOString(), 
        expires_at: expiresAt 
      })
      .eq("id", key.id);
  }

  const remainingMs = new Date(expiresAt!).getTime() - Date.now();
  
  await logApiRequest(supabase, clientIp, "activate", key_code, true, null, null);

  return jsonResponse({
    success: true,
    activated: true,
    expires_at: expiresAt,
    remaining_seconds: Math.floor(remainingMs / 1000),
    game_id: key.game_id,
    game_name: key.games?.name,
    mod_name: key.games?.mod_name,
  }, 200, corsHeaders);
}

async function handleVerify(
  supabase: SupabaseClient,
  body: { key_code: string; device_fingerprint: string },
  clientIp: string,
  corsHeaders: Record<string, string>
) {
  const { key_code, device_fingerprint } = body;

  if (!key_code || !device_fingerprint) {
    await logApiRequest(supabase, clientIp, "verify", key_code, false, "MISSING_FIELDS", null);
    return jsonResponse({ valid: false, error: "Invalid request" }, 400, corsHeaders);
  }

  const { data: key, error } = await supabase
    .from("license_keys")
    .select("*, games(name, mod_name)")
    .eq("key_code", key_code)
    .single<LicenseKey>();

  if (error || !key) {
    await trackFailedAttempt(supabase, clientIp, "INVALID_KEY");
    await logApiRequest(supabase, clientIp, "verify", key_code, false, "INVALID_KEY", null);
    return jsonResponse({ valid: false, error: "Invalid request" }, 200, corsHeaders);
  }

  // Check expiration
  if (key.expires_at && new Date(key.expires_at) < new Date()) {
    if (key.status === "active") {
      await supabase.from("key_activations").delete().eq("key_id", key.id);
      await supabase.from("license_keys").update({ status: "expired" }).eq("id", key.id);
    }
    await logApiRequest(supabase, clientIp, "verify", key_code, false, "KEY_EXPIRED", null);
    return jsonResponse({ valid: false, error: "Unable to verify" }, 200, corsHeaders);
  }

  if (key.status !== "active") {
    await logApiRequest(supabase, clientIp, "verify", key_code, false, `KEY_${key.status.toUpperCase()}`, null);
    return jsonResponse({ valid: false, error: "Unable to verify" }, 200, corsHeaders);
  }

  // Verify device is registered
  const { data: activation } = await supabase
    .from("key_activations")
    .select("*")
    .eq("key_id", key.id)
    .eq("device_fingerprint", device_fingerprint)
    .maybeSingle<KeyActivation>();

  if (!activation) {
    await logApiRequest(supabase, clientIp, "verify", key_code, false, "DEVICE_NOT_REGISTERED", null);
    return jsonResponse({ valid: false, error: "Unable to verify" }, 200, corsHeaders);
  }

  const remainingMs = new Date(key.expires_at!).getTime() - Date.now();
  
  await logApiRequest(supabase, clientIp, "verify", key_code, true, null, null);

  return jsonResponse({
    valid: true,
    remaining_seconds: Math.floor(remainingMs / 1000),
    expires_at: key.expires_at,
    game_name: key.games?.name,
    mod_name: key.games?.mod_name,
  }, 200, corsHeaders);
}

async function handleConnect(
  supabase: SupabaseClient,
  body: { 
    game: string; 
    user_key: string; 
    serial: string; 
    device_info?: Record<string, unknown>;
    legacy?: string | number | boolean;
  },
  clientIp: string,
  corsHeaders: Record<string, string>
) {
  const { game = "", user_key, serial, device_info } = body;

  // Validate required fields
  if (!user_key || !serial) {
    await logApiRequest(supabase, clientIp, "connect", user_key, false, "MISSING_FIELDS", { game });
    return jsonResponse({
      status: false,
      reason: "INVALID_REQUEST",
      message: "Unable to process request",
      data: null
    }, 400, corsHeaders);
  }

  // Check if game-agnostic mode
  const isGameAgnostic = !game || game === "" || game.toUpperCase() === "AUTO";

  // Try to find game data if specific game provided
  let gameData: { id: string; name: string; mod_name: string | null } | null = null;
  if (!isGameAgnostic) {
    const { data } = await supabase
      .from("games")
      .select("id, name, mod_name")
      .ilike("name", game)
      .eq("status", "active")
      .maybeSingle<{ id: string; name: string; mod_name: string | null }>();
    gameData = data;
  }

  // Try exact game match first, then fall back to game-agnostic lookup
  let key: LicenseKey | null = null;
  let keyGameData: { id: string; name: string; mod_name: string | null } | null = gameData;

  if (gameData) {
    const { data: exactKey } = await supabase
      .from("license_keys")
      .select("*, games(id, name, mod_name)")
      .eq("key_code", user_key)
      .eq("game_id", gameData.id)
      .maybeSingle<LicenseKey>();
    key = exactKey;
  }

  // If no exact match OR game-agnostic mode, find key by key_code only
  if (!key) {
    const { data: anyKey } = await supabase
      .from("license_keys")
      .select("*, games(id, name, mod_name)")
      .eq("key_code", user_key)
      .single<LicenseKey>();
    
    if (anyKey) {
      key = anyKey;
      keyGameData = anyKey.games || null;
    }
  }

  if (!key) {
    await trackFailedAttempt(supabase, clientIp, "INVALID_KEY");
    await logApiRequest(supabase, clientIp, "connect", user_key, false, "INVALID_KEY", { game });
    return jsonResponse({
      status: false,
      reason: "INVALID_REQUEST",
      message: "Unable to process request",
      data: null
    }, 200, corsHeaders);
  }

  // OBFUSCATED: All status errors return generic message
  if (key.status === "revoked" || key.status === "paused") {
    await logApiRequest(supabase, clientIp, "connect", user_key, false, `KEY_${key.status.toUpperCase()}`, { game });
    return jsonResponse({
      status: false,
      reason: "INVALID_REQUEST",
      message: "Unable to process request",
      data: null
    }, 200, corsHeaders);
  }

  // Check expiration
  if (key.expires_at && new Date(key.expires_at) < new Date()) {
    await supabase.from("license_keys").update({ status: "expired" }).eq("id", key.id);
    await logApiRequest(supabase, clientIp, "connect", user_key, false, "KEY_EXPIRED", { game });
    return jsonResponse({
      status: false,
      reason: "INVALID_REQUEST",
      message: "Unable to process request",
      data: null
    }, 200, corsHeaders);
  }

  // Count current activations
  const { count: currentDevices } = await supabase
    .from("key_activations")
    .select("*", { count: "exact", head: true })
    .eq("key_id", key.id);

  // Check if device already registered ON THIS KEY
  const { data: existingActivation } = await supabase
    .from("key_activations")
    .select("*")
    .eq("key_id", key.id)
    .eq("device_fingerprint", serial)
    .maybeSingle<KeyActivation>();

  if (existingActivation) {
    // Device already on this key - just update last_seen
    await supabase
      .from("key_activations")
      .update({ 
        last_seen: new Date().toISOString(),
        ip_address: clientIp,
        device_info: device_info || existingActivation.device_info
      })
      .eq("id", existingActivation.id);
  } else {
    // NEW KEY ACTIVATION - Remove device from ALL other keys first
    // This allows users to migrate to new keys seamlessly
    const { data: oldActivations } = await supabase
      .from("key_activations")
      .select("id, key_id")
      .eq("device_fingerprint", serial)
      .neq("key_id", key.id);
    
    if (oldActivations && oldActivations.length > 0) {
      // Remove device from old keys
      await supabase
        .from("key_activations")
        .delete()
        .eq("device_fingerprint", serial)
        .neq("key_id", key.id);
      
      console.log(`Device ${serial.substring(0, 8)}... migrated from ${oldActivations.length} old key(s) to new key`);
    }

    // Now check device limit for this key
    if ((currentDevices || 0) >= key.max_devices) {
      await logApiRequest(supabase, clientIp, "connect", user_key, false, "MAX_DEVICES", { game });
      return jsonResponse({
        status: false,
        reason: "INVALID_REQUEST",
        message: "Unable to process request",
        data: null
      }, 200, corsHeaders);
    }

    const { error: insertError } = await supabase.from("key_activations").insert({
      key_id: key.id,
      device_fingerprint: serial,
      device_info: device_info || {},
      ip_address: clientIp,
    });

    if (insertError) {
      console.error("Activation error");
      await logApiRequest(supabase, clientIp, "connect", user_key, false, "INSERT_ERROR", { game });
      return jsonResponse({
        status: false,
        reason: "INVALID_REQUEST",
        message: "Unable to process request",
        data: null
      }, 500, corsHeaders);
    }
  }

  // Set activation time if first activation
  let expiresAt = key.expires_at;
  if (!key.activated_at) {
    expiresAt = new Date(Date.now() + key.duration_hours * 60 * 60 * 1000).toISOString();
    await supabase
      .from("license_keys")
      .update({ 
        activated_at: new Date().toISOString(), 
        expires_at: expiresAt 
      })
      .eq("id", key.id);
  }

  // Calculate remaining time
  const remainingMs = new Date(expiresAt!).getTime() - Date.now();
  const remainingSeconds = Math.floor(remainingMs / 1000);
  const daysRemaining = Math.ceil(remainingMs / (1000 * 60 * 60 * 24));

  // ============================================
  // SECRET FROM ENVIRONMENT VARIABLE
  // ============================================
  const SECRET = Deno.env.get("CLIENT_AUTH_SECRET")!;
  
  if (!SECRET) {
    console.error("CLIENT_AUTH_SECRET not configured");
    return jsonResponse({
      status: false,
      reason: "INVALID_REQUEST",
      message: "Unable to process request",
      data: null
    }, 500, corsHeaders);
  }
  
  // ALWAYS use "PUBG" for legacy client compatibility
  const authString = `PUBG-${user_key}-${serial}-${SECRET}`;
  const md5Token = md5Hash(authString);
  
  // Current timestamp for rng validation (client checks ±15 seconds - tightened from 30)
  const rng = Math.floor(Date.now() / 1000);
  
  // Format expiry date
  const expiryDate = new Date(expiresAt!);
  const ts = expiryDate.toISOString().split('T')[0];
  
  // Format EXP as human readable duration
  const EXP = formatDuration(key.duration_hours);

  // Get mod_name from key's game data or fallback
  const actualGameName = keyGameData?.name?.toUpperCase() || "PUBG";
  const modName = keyGameData?.mod_name || `${actualGameName} Mod`;
  
  const ms = key.status;
  const fAVA = ms;

  // Legacy mode check
  const isLegacyMode = body.legacy === "1" || body.legacy === 1 || body.legacy === true;
  const tokenValue = isLegacyMode ? "1" : md5Token;

  await logApiRequest(supabase, clientIp, "connect", user_key, true, null, { game });

  return jsonResponse({
    status: 69,
    reason: null,
    data: {
      token: tokenValue,
      game_name: actualGameName,
      mod_name: modName,
      expiry: expiresAt,
      days_remaining: daysRemaining,
      remaining_seconds: remainingSeconds,
      max_devices: key.max_devices,
      current_devices: (currentDevices || 0) + (existingActivation ? 0 : 1),
      rng: rng,
      EXP: EXP,
      ts: ts,
      ms: ms,
      fAVA: fAVA
    }
  }, 200, corsHeaders);
}

async function handleSdkConnect(
  supabase: SupabaseClient,
  body: {
    user_key?: string;
    package_name?: string;
    serial?: string;
    device_info?: Record<string, unknown>;
  },
  clientIp: string,
  corsHeaders: Record<string, string>
) {
  const { user_key, package_name, serial, device_info } = body;

  if (!user_key || !package_name) {
    await logApiRequest(supabase, clientIp, "sdk_connect", user_key || "", false, "MISSING_FIELDS", { package_name });
    return jsonResponse({
      status: false,
      reason: "INVALID_REQUEST",
      message: "Unable to process request",
      data: null,
    }, 400, corsHeaders);
  }

  // Lookup license key
  const { data: key } = await supabase
    .from("license_keys")
    .select("*, games(id, name, mod_name)")
    .eq("key_code", user_key)
    .maybeSingle<LicenseKey & { package_restricted?: boolean }>();

  if (!key) {
    await trackFailedAttempt(supabase, clientIp, "INVALID_KEY");
    await logApiRequest(supabase, clientIp, "sdk_connect", user_key, false, "INVALID_KEY", { package_name });
    return jsonResponse({
      status: false,
      reason: "INVALID_REQUEST",
      message: "Unable to process request",
      data: null,
    }, 200, corsHeaders);
  }

  // Package verification (only if key has package_restricted = true)
  if ((key as any).package_restricted === true) {
    const { data: pkg } = await supabase
      .from("approved_packages")
      .select("id")
      .eq("package_name", package_name)
      .eq("is_active", true)
      .or(`game_id.eq.${key.game_id},game_id.is.null`)
      .maybeSingle();

    if (!pkg) {
      await logApiRequest(supabase, clientIp, "sdk_connect", user_key, false, "PACKAGE_NOT_APPROVED", { package_name });
      return jsonResponse({
        status: false,
        reason: "INVALID_REQUEST",
        message: "Unable to process request",
        data: null,
      }, 200, corsHeaders);
    }
  }

  if (key.status === "revoked" || key.status === "paused") {
    await logApiRequest(supabase, clientIp, "sdk_connect", user_key, false, `KEY_${key.status.toUpperCase()}`, { package_name });
    return jsonResponse({
      status: false, reason: "INVALID_REQUEST", message: "Unable to process request", data: null,
    }, 200, corsHeaders);
  }

  if (key.expires_at && new Date(key.expires_at) < new Date()) {
    await supabase.from("license_keys").update({ status: "expired" }).eq("id", key.id);
    return jsonResponse({
      status: false, reason: "INVALID_REQUEST", message: "Unable to process request", data: null,
    }, 200, corsHeaders);
  }

  // Device tracking (use package_name as serial fallback for SDK clients)
  const deviceFp = serial || `pkg:${package_name}`;

  const { count: currentDevices } = await supabase
    .from("key_activations")
    .select("*", { count: "exact", head: true })
    .eq("key_id", key.id);

  const { data: existingActivation } = await supabase
    .from("key_activations")
    .select("*")
    .eq("key_id", key.id)
    .eq("device_fingerprint", deviceFp)
    .maybeSingle<KeyActivation>();

  if (existingActivation) {
    await supabase
      .from("key_activations")
      .update({ last_seen: new Date().toISOString(), ip_address: clientIp, device_info: device_info || existingActivation.device_info })
      .eq("id", existingActivation.id);
  } else {
    if ((currentDevices || 0) >= key.max_devices) {
      await logApiRequest(supabase, clientIp, "sdk_connect", user_key, false, "MAX_DEVICES", { package_name });
      return jsonResponse({
        status: false, reason: "INVALID_REQUEST", message: "Unable to process request", data: null,
      }, 200, corsHeaders);
    }
    await supabase.from("key_activations").insert({
      key_id: key.id,
      device_fingerprint: deviceFp,
      device_info: { ...(device_info || {}), package_name, sdk: true },
      ip_address: clientIp,
    });
  }

  // Activate on first use
  let expiresAt = key.expires_at;
  if (!key.activated_at) {
    expiresAt = new Date(Date.now() + key.duration_hours * 60 * 60 * 1000).toISOString();
    await supabase.from("license_keys").update({
      activated_at: new Date().toISOString(), expires_at: expiresAt,
    }).eq("id", key.id);
  }

  const remainingMs = new Date(expiresAt!).getTime() - Date.now();
  const remainingSeconds = Math.floor(remainingMs / 1000);
  const daysRemaining = Math.ceil(remainingMs / (1000 * 60 * 60 * 24));

  const SECRET = Deno.env.get("CLIENT_AUTH_SECRET")!;
  const authString = `SDK-${user_key}-${package_name}-${SECRET}`;
  const md5Token = md5Hash(authString);
  const rng = Math.floor(Date.now() / 1000);

  await logApiRequest(supabase, clientIp, "sdk_connect", user_key, true, null, { package_name });

  return jsonResponse({
    status: true,
    reason: null,
    data: {
      token: md5Token,
      package_name,
      expiry: expiresAt,
      days_remaining: daysRemaining,
      remaining_seconds: remainingSeconds,
      max_devices: key.max_devices,
      current_devices: (currentDevices || 0) + (existingActivation ? 0 : 1),
      rng,
      ts: new Date(expiresAt!).toISOString().split("T")[0],
      EXP: formatDuration(key.duration_hours),
    },
  }, 200, corsHeaders);
}

async function handleHeartbeat(
  supabase: SupabaseClient,
  body: { key_code: string; device_fingerprint: string },
  clientIp: string,
  corsHeaders: Record<string, string>
) {
  return await _handleHeartbeat(supabase, body, clientIp, corsHeaders);
}

// ============================================
// LEGACY/JAVA SDK ENDPOINT
// Accepts form-urlencoded: user_key, package_name, app_name, device_id
// Returns flat: {status:"success", expiry:"..."} or {status:"fail", reason:"..."}
// ============================================
async function handleSdkVerify(
  supabase: SupabaseClient,
  body: {
    user_key?: string;
    package_name?: string;
    app_name?: string;
    device_id?: string;
  },
  clientIp: string,
  corsHeaders: Record<string, string>
) {
  const user_key = (body.user_key || "").trim();
  const package_name = (body.package_name || "").trim();
  const app_name = (body.app_name || "").trim();
  const device_id = (body.device_id || "").trim() || `pkg:${package_name}`;

  const fail = (reason: string, http = 200) => jsonResponse({ status: "fail", reason }, http, corsHeaders);

  if (!user_key || !package_name) {
    await logApiRequest(supabase, clientIp, "sdk_verify", user_key, false, "MISSING_FIELDS", { package_name });
    return fail("Missing user_key or package_name", 400);
  }

  const { data: key } = await supabase
    .from("license_keys")
    .select("*, games(id, name, mod_name)")
    .eq("key_code", user_key)
    .maybeSingle<LicenseKey & { package_restricted?: boolean }>();

  if (!key) {
    await trackFailedAttempt(supabase, clientIp, "INVALID_KEY");
    await logApiRequest(supabase, clientIp, "sdk_verify", user_key, false, "INVALID_KEY", { package_name });
    return fail("Invalid license key");
  }

  if ((key as any).package_restricted === true) {
    const { data: pkg } = await supabase
      .from("approved_packages")
      .select("id")
      .eq("package_name", package_name)
      .eq("is_active", true)
      .or(`game_id.eq.${key.game_id},game_id.is.null`)
      .maybeSingle();

    if (!pkg) {
      await logApiRequest(supabase, clientIp, "sdk_verify", user_key, false, "PACKAGE_NOT_APPROVED", { package_name });
      return fail("Package not approved for this key");
    }
  }

  if (key.status === "revoked" || key.status === "paused") {
    await logApiRequest(supabase, clientIp, "sdk_verify", user_key, false, `KEY_${key.status.toUpperCase()}`, { package_name });
    return fail(`Key ${key.status}`);
  }

  if (key.expires_at && new Date(key.expires_at) < new Date()) {
    await supabase.from("license_keys").update({ status: "expired" }).eq("id", key.id);
    await logApiRequest(supabase, clientIp, "sdk_verify", user_key, false, "KEY_EXPIRED", { package_name });
    return fail("License expired");
  }

  // Device tracking — device_id is the fingerprint
  const deviceFp = device_id;

  const { count: currentDevices } = await supabase
    .from("key_activations")
    .select("*", { count: "exact", head: true })
    .eq("key_id", key.id);

  const { data: existingActivation } = await supabase
    .from("key_activations")
    .select("*")
    .eq("key_id", key.id)
    .eq("device_fingerprint", deviceFp)
    .maybeSingle<KeyActivation>();

  if (existingActivation) {
    await supabase
      .from("key_activations")
      .update({
        last_seen: new Date().toISOString(),
        ip_address: clientIp,
        device_info: { package_name, app_name, device_id, sdk: true },
      })
      .eq("id", existingActivation.id);
  } else {
    if ((currentDevices || 0) >= key.max_devices) {
      await logApiRequest(supabase, clientIp, "sdk_verify", user_key, false, "MAX_DEVICES", { package_name });
      return fail("Device limit reached");
    }
    await supabase.from("key_activations").insert({
      key_id: key.id,
      device_fingerprint: deviceFp,
      device_info: { package_name, app_name, device_id, sdk: true },
      ip_address: clientIp,
    });
  }

  // Activate on first use
  let expiresAt = key.expires_at;
  if (!key.activated_at) {
    expiresAt = new Date(Date.now() + key.duration_hours * 60 * 60 * 1000).toISOString();
    await supabase.from("license_keys").update({
      activated_at: new Date().toISOString(),
      expires_at: expiresAt,
    }).eq("id", key.id);
  }

  await logApiRequest(supabase, clientIp, "sdk_verify", user_key, true, null, { package_name });

  return jsonResponse({
    status: "success",
    expiry: expiresAt,
    package_name,
  }, 200, corsHeaders);
}

async function _handleHeartbeat(
  supabase: SupabaseClient,
  body: { key_code: string; device_fingerprint: string },
  clientIp: string,
  corsHeaders: Record<string, string>
) {
  const { key_code, device_fingerprint } = body;

  if (!key_code || !device_fingerprint) {
    return jsonResponse({ success: false, error: "Invalid request" }, 400, corsHeaders);
  }

  const { data: key } = await supabase
    .from("license_keys")
    .select("id, status, expires_at")
    .eq("key_code", key_code)
    .single<{ id: string; status: string; expires_at: string | null }>();

  if (!key) {
    return jsonResponse({ success: false, error: "Invalid request" }, 200, corsHeaders);
  }

  if (key.status !== "active") {
    return jsonResponse({ success: false, error: "Unable to process" }, 200, corsHeaders);
  }

  // Check expiration
  if (key.expires_at && new Date(key.expires_at) < new Date()) {
    await supabase.from("license_keys").update({ status: "expired" }).eq("id", key.id);
    return jsonResponse({ success: false, expired: true, error: "Unable to process" }, 200, corsHeaders);
  }

  // Check if device is registered
  const { data: activation } = await supabase
    .from("key_activations")
    .select("id")
    .eq("key_id", key.id)
    .eq("device_fingerprint", device_fingerprint)
    .maybeSingle();

  if (!activation) {
    return jsonResponse({ success: false, error: "Unable to process" }, 200, corsHeaders);
  }

  // Update last_seen
  await supabase
    .from("key_activations")
    .update({ 
      last_seen: new Date().toISOString(),
      ip_address: clientIp
    })
    .eq("id", activation.id);

  const remainingMs = new Date(key.expires_at!).getTime() - Date.now();

  return jsonResponse({
    success: true,
    remaining_seconds: Math.floor(remainingMs / 1000),
    expires_at: key.expires_at,
  }, 200, corsHeaders);
}

Deno.serve(async (req) => {
  const corsHeaders = getCorsHeaders(req);
  
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405, corsHeaders);
  }

  // WAF Rule: Block known automation User-Agents (skip for C++ game clients)
  const userAgent = (req.headers.get("user-agent") || "").toLowerCase();
  const isGameClient = req.headers.get("x-client-info") === undefined && !req.headers.get("origin");
  if (!isGameClient && userAgent.length > 0) {
    for (const blocked of BLOCKED_USER_AGENTS) {
      if (userAgent.includes(blocked)) {
        return jsonResponse({ status: false, reason: "BLOCKED_UA", message: "Unable to process request" }, 403, corsHeaders);
      }
    }
  }

  // Check content length
  const contentLength = parseInt(req.headers.get("content-length") || "0");
  if (contentLength > MAX_BODY_SIZE) {
    return jsonResponse({ status: false, reason: "PAYLOAD_TOO_LARGE", message: "Request too large" }, 413, corsHeaders);
  }

  const url = new URL(req.url);
  const pathParts = url.pathname.split("/").filter(Boolean);
  const endpoint = pathParts[pathParts.length - 1];

  // Detect SDK route: /sarkar-api/sdk/panel/connect
  const isSdkRoute = pathParts.includes("sdk") && pathParts.includes("panel");

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const clientIp = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || 
                   req.headers.get("x-real-ip") || 
                   "unknown";

  // ============================================
  // ANTI-CANARY: honeypot path detection (before any DB work besides ban write)
  // ============================================
  const fullPath = url.pathname;
  for (const pat of CANARY_PATH_PATTERNS) {
    if (pat.test(fullPath)) {
      await tripCanary(supabase, clientIp, fullPath, "HONEYPOT_PATH", userAgent);
      return jsonResponse({ error: "Not found" }, 404, corsHeaders);
    }
  }

  // Validate endpoint name (prevent path traversal) — and unknown endpoint = canary
  if (!/^[a-z\-]+$/.test(endpoint) || (!isSdkRoute && !VALID_ENDPOINTS.has(endpoint))) {
    await tripCanary(supabase, clientIp, fullPath, "UNKNOWN_ENDPOINT", userAgent);
    return jsonResponse({ error: "Not found" }, 404, corsHeaders);
  }

  try {
    // ============================================
    // SECURITY CHECKS
    // ============================================
    
    // 1. Check IP blacklist
    if (await isIpBlacklisted(supabase, clientIp)) {
      return jsonResponse({ 
        status: false, 
        reason: "BLOCKED",
        message: "Unable to process request"
      }, 403, corsHeaders);
    }

    // 2. Check rate limit (SDK connect uses its own bucket so it doesn't share quota with C++ /connect)
    const rateLimitKey = (endpoint === "connect" && isSdkRoute) ? "sdk-connect" : endpoint;
    if (!await checkRateLimit(supabase, clientIp, rateLimitKey)) {
      return jsonResponse({ 
        status: false, 
        reason: "RATE_LIMITED",
        message: "Too many requests, slow down"
      }, 429, corsHeaders);
    }

    // 3. Parse request body with size guard
    let body: Record<string, string>;
    try {
      body = await parseBody(req);
    } catch {
      return jsonResponse({ status: false, reason: "INVALID_PAYLOAD", message: "Invalid request body" }, 400, corsHeaders);
    }

    // 4. Sanitize all string fields - truncate and check for injection
    for (const [key, value] of Object.entries(body)) {
      if (typeof value === "string") {
        if (value.length > MAX_FIELD_LENGTH) {
          return jsonResponse({ status: false, reason: "FIELD_TOO_LONG", message: "Unable to process request" }, 400, corsHeaders);
        }
      }
    }

    // 5. Anti-debug signal trap (any frida/xposed/debugger/emulator/hook = ban)
    const tripped = detectDebugSignal(body as Record<string, unknown>);
    if (tripped) {
      await tripCanary(supabase, clientIp, fullPath, `DEBUG_SIGNAL:${tripped}`, userAgent, { endpoint });
      return jsonResponse({ status: false, reason: "INVALID_REQUEST", message: "Unable to process request" }, 200, corsHeaders);
    }

    // 6. SDK route: enforce HMAC signature + replay nonce
    if (isSdkRoute && endpoint === "connect") {
      const SECRET = Deno.env.get("CLIENT_AUTH_SECRET");
      if (SECRET) {
        const sigCheck = await verifySdkSignature(supabase, req, body as any, SECRET);
        if (!sigCheck.ok) {
          await trackFailedAttempt(supabase, clientIp, `SDK_${sigCheck.reason}`).catch(() => {});
          await logApiRequest(supabase, clientIp, "sdk_connect", (body as any).user_key || "", false, sigCheck.reason, null);
          // Stale/replayed/missing sig is suspicious — count toward ban
          return jsonResponse({ status: false, reason: "INVALID_REQUEST", message: "Unable to process request" }, 401, corsHeaders);
        }
      }
    }

    switch (endpoint) {
      case "connect":
        if (isSdkRoute) {
          return await handleSdkConnect(supabase, body as any, clientIp, corsHeaders);
        }
        return await handleConnect(supabase, body as any, clientIp, corsHeaders);
      case "connect-enc": {
        const inner = await handleConnect(supabase, body as any, clientIp, corsHeaders);
        return await toEncryptedResponse(inner, corsHeaders);
      }
      case "activate":
        return await handleActivate(supabase, body as any, clientIp, corsHeaders);
      case "verify":
        return await handleVerify(supabase, body as any, clientIp, corsHeaders);
      case "heartbeat":
        return await handleHeartbeat(supabase, body as any, clientIp, corsHeaders);
      case "sdk-verify":
        return await handleSdkVerify(supabase, body as any, clientIp, corsHeaders);
      default:
        return jsonResponse({ 
          error: "Unknown endpoint"
        }, 404, corsHeaders);
    }
  } catch (error) {
    console.error("API error");
    return jsonResponse({ 
      status: false,
      reason: "INTERNAL_ERROR",
      message: "Unable to process request"
    }, 500, corsHeaders);
  }
});
