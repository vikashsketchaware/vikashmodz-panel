// Razorpay webhook handler — per-bot signature verification + auto key delivery
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

async function hmacSha256Hex(secret: string, body: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(body));
  return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, "0")).join("");
}

async function notifyTelegram(token: string, chatId: number | string, text: string) {
  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML" }),
    });
  } catch (_) { /* swallow */ }
}

function generateLicenseKey(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const parts: string[] = [];
  for (let s = 0; s < 4; s++) {
    let seg = "";
    for (let j = 0; j < 4; j++) seg += chars.charAt(Math.floor(Math.random() * chars.length));
    parts.push(seg);
  }
  return parts.join("-");
}

function formatDuration(h: number): string {
  if (h < 24) return `${h} Hour${h > 1 ? "s" : ""}`;
  const d = Math.floor(h / 24);
  return `${d} Day${d > 1 ? "s" : ""}`;
}

async function deliverKey(supabase: any, bot: any, order: any) {
  // Find active game (fallback)
  let gameId = order.game_id as string | null;
  if (!gameId) {
    const { data: g } = await supabase.from("games").select("id").eq("status", "active").limit(1).maybeSingle();
    gameId = g?.id || null;
  }

  const durationHours = order.duration_hours || 24;
  const expiresAt = new Date(Date.now() + durationHours * 60 * 60 * 1000).toISOString();
  const licenseKey = generateLicenseKey();

  const { data: keyRow, error: keyErr } = await supabase.from("license_keys").insert({
    key_code: licenseKey,
    game_id: gameId,
    duration_hours: durationHours,
    max_devices: 1,
    status: "active",
    created_by: null,
    price: order.amount,
    expires_at: expiresAt,
    telegram_id: order.telegram_user_id,
    telegram_username: order.telegram_username,
    transaction_id: order.provider_payment_id,
    bot_id: bot.id,
  }).select().single();

  if (keyErr) {
    await notifyTelegram(bot.bot_token, bot.admin_chat_id,
      `⚠️ <b>Key delivery FAILED</b>\nOrder: <code>${order.id}</code>\nError: ${keyErr.message}\n\nManually deliver to user <code>${order.telegram_user_id}</code>.`);
    return null;
  }

  await supabase.from("bot_orders").update({
    status: "delivered",
    delivered_key_id: keyRow.id,
  }).eq("id", order.id);

  // Coupon usage
  if (order.coupon_code) {
    await supabase.rpc("increment_referral_usage", {}).catch(() => {}); // ignore
    await supabase.from("bot_coupons")
      .update({ times_used: (await supabase.from("bot_coupons").select("times_used").eq("bot_id", bot.id).eq("code", order.coupon_code).maybeSingle()).data?.times_used + 1 || 1 })
      .eq("bot_id", bot.id).eq("code", order.coupon_code);
  }

  // Send key to buyer
  await notifyTelegram(bot.bot_token, order.telegram_user_id, `
✅ <b>Payment Successful!</b>

🔑 <b>License Key:</b> <code>${licenseKey}</code>
⏱ <b>Duration:</b> ${formatDuration(durationHours)}
💰 <b>Amount Paid:</b> ₹${order.amount}
🧾 <b>Payment ID:</b> <code>${order.provider_payment_id}</code>

Thank you for your purchase! 🙏
`);

  // Notify owner
  await notifyTelegram(bot.bot_token, bot.admin_chat_id,
    `✅ <b>Auto-delivered</b>\nKey: <code>${licenseKey}</code>\nBuyer: ${order.telegram_username ? "@" + order.telegram_username : order.telegram_user_id}\nAmount: ₹${order.amount}`);

  // Low-stock alert (count unused keys for this bot)
  if (bot.low_stock_threshold && bot.low_stock_threshold > 0) {
    const { count } = await supabase
      .from("license_keys")
      .select("id", { count: "exact", head: true })
      .eq("bot_id", bot.id)
      .eq("status", "active")
      .is("telegram_id", null);
    if (typeof count === "number" && count <= bot.low_stock_threshold) {
      await notifyTelegram(bot.bot_token, bot.admin_chat_id,
        `⚠️ <b>LOW STOCK ALERT</b>\nUnused keys: <b>${count}</b> (threshold ${bot.low_stock_threshold})`);
    }
  }

  return keyRow;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405, headers: corsHeaders });

  const url = new URL(req.url);
  const botId = url.searchParams.get("bot_id");
  if (!botId) return new Response(JSON.stringify({ error: "bot_id required" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  const signature = req.headers.get("x-razorpay-signature") || "";
  const rawBody = await req.text();

  const supabase = createClient(SUPABASE_URL, SERVICE_KEY);
  const { data: bot, error: botErr } = await supabase
    .from("telegram_bots")
    .select("id, bot_token, admin_chat_id, razorpay_webhook_secret, payment_mode, is_active, low_stock_threshold")
    .eq("id", botId)
    .maybeSingle();

  if (botErr || !bot) return new Response(JSON.stringify({ error: "bot not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  if (!bot.razorpay_webhook_secret) return new Response(JSON.stringify({ error: "webhook secret not configured" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  const expected = await hmacSha256Hex(bot.razorpay_webhook_secret, rawBody);
  if (expected !== signature) {
    return new Response(JSON.stringify({ error: "invalid signature" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  let payload: any;
  try { payload = JSON.parse(rawBody); } catch { return new Response("bad json", { status: 400, headers: corsHeaders }); }

  const event = payload?.event;
  const payment = payload?.payload?.payment?.entity;
  const paymentLink = payload?.payload?.payment_link?.entity;

  // Payment Link events carry reference_id = our order_id
  const ourOrderId = paymentLink?.reference_id || payment?.notes?.order_id;
  const providerOrderId = paymentLink?.id || payment?.order_id;

  if (event === "payment_link.paid" || event === "payment.captured") {
    let order: any = null;
    if (ourOrderId) {
      const r = await supabase.from("bot_orders").select("*").eq("id", ourOrderId).eq("bot_id", botId).maybeSingle();
      order = r.data;
    }
    if (!order && providerOrderId) {
      const r = await supabase.from("bot_orders").select("*").eq("provider_order_id", providerOrderId).eq("bot_id", botId).maybeSingle();
      order = r.data;
    }
    if (order && (order.status === "pending" || order.status === "paid")) {
      await supabase.from("bot_orders").update({
        status: "paid",
        provider_payment_id: payment?.id || order.provider_payment_id,
      }).eq("id", order.id);
      const refreshed = { ...order, provider_payment_id: payment?.id || order.provider_payment_id };
      await deliverKey(supabase, bot, refreshed);
    }
  } else if (event === "payment.failed" || event === "payment_link.cancelled" || event === "payment_link.expired") {
    if (ourOrderId || providerOrderId) {
      const q = supabase.from("bot_orders").update({ status: "failed" }).eq("bot_id", botId);
      const final = ourOrderId ? q.eq("id", ourOrderId) : q.eq("provider_order_id", providerOrderId);
      const { data: failedOrder } = await supabase.from("bot_orders").select("telegram_user_id, amount").match(ourOrderId ? { id: ourOrderId, bot_id: botId } : { provider_order_id: providerOrderId, bot_id: botId }).maybeSingle();
      await final;
      if (failedOrder) {
        await notifyTelegram(bot.bot_token, failedOrder.telegram_user_id,
          `❌ <b>Payment Failed/Declined</b>\nAmount: ₹${failedOrder.amount}\n\nIf paisa kata hai, owner se contact karo.`);
        await notifyTelegram(bot.bot_token, bot.admin_chat_id,
          `❌ <b>Payment Failed</b>\nUser: <code>${failedOrder.telegram_user_id}</code>\nAmount: ₹${failedOrder.amount}`);
      }
    }
  }

  return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
});