import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    hmr: {
      overlay: false,
    },
  },
  plugins: [react(), mode === "development" && componentTagger()].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  // Strip all console.* and debugger statements from production builds
  // (zero leaks from client-side: no logs, no debug info exposed in DevTools)
  esbuild: mode === "production"
    ? { drop: ["console", "debugger"], legalComments: "none" }
    : undefined,
}));
